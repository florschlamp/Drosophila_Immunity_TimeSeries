#! /bin/bash

#$ -S /bin/bash
#$ -q regular.q
#$ -j y
#$ -N m.5.15.pw
#$ -M mfs97@cornell.edu
#$ -m be
#$ -pe bscb 12
#$ -l h_vmem=64G
#$ -cwd

date
d1=$(date +%s)
types=master_list
start_tp=15
end_tp=20

mkdir -p /SSD/$USER/$JOB_ID
cd /SSD/$USER/$JOB_ID

#======== start ===================

cp /bscb/bscb02/mfs97/fly_immunity/GCnet_May2019/InitialData.Rdata ./
cp /bscb/bscb02/mfs97/fly_immunity/GCnet_May2019/functions.r ./
cp /bscb/bscb02/mfs97/fly_immunity/GCnet_May2019/library.r ./
cp /bscb/bscb02/mfs97/fly_immunity/GCnet_May2019/lasso_inference.r ./
cp /bscb/bscb02/mfs97/fly_immunity/GCnet_May2019/GCnetwork_script_generate-tables_pw.R ./

R -f GCnetwork_script_generate-tables_pw.R $types $start_tp $end_tp

cp GC*pw* /bscb/bscb02/mfs97/fly_immunity/GCnet_May2019/

# ====== DONE ======
rm -r /SSD/$USER/$JOB_ID/

date
d2=$(date +%s)
sec=$(( ( $d2 - $d1 ) ))
hour=$(echo - | awk '{ print '$sec'/3600}')
echo Runtime: $hour hours \($sec\s\)

