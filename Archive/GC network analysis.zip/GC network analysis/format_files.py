
import os

list_of_files = os.listdir("/Users/florschlamp/Dropbox/Drosophila_Immunity_time_course/Dec_2017/Results/GCnet_May2019/")

for filename in list_of_files:
	name = filename[3:][:-4]
	if "lasso" in name:
		data=[line.strip().split('\t') for line in open("results/GC_%s.txt"%(name))][1:]
		output = open("GC_%s_formatted.txt"%(name),"w")

		i =0
		for line in data:
			i = i+1
			output.write("%s\t%s\t%s\n"%(name,str(i),"\t".join(line[1:])))
		output.close()
	else:
		data=[line.strip().split('\t') for line in open("results/GC_%s.txt"%(name))][1:]
		output = open("GC_%s_formatted.txt"%(name),"w")

		i =0
		for line in data:
			i = i+1
			output.write("%s\t%s\t%s\n"%(name,str(i),"\t".join(line)))
		output.close()
