# using different sets of genes
#install.packages("flare",lib="~/Rlibs")
#install.packages("ppcor",lib="~/Rlibs")

library(flare,lib.loc="~/Rlibs/")
library(ppcor,lib.loc="~/Rlibs/")

source('functions.r')
load("InitialData.Rdata")

# START OF PARAMETERS
#type = 'master_list'
#start_tp = 1
#end_tp = 6

args <- commandArgs(trailingOnly=FALSE)
type = args[4]
start_tp = as.numeric(args[5])
end_tp = as.numeric(args[6])

print(paste0("number of cores: ",n_cores))

if(type == 'master_list'){
  desired_dataset = master_list
}

tps = start_tp:end_tp

tp_name = paste0(start_tp,"to",end_tp)

out <- GCnet_l1var(dat.A = dat.A, dat.B = dat.B, 
                   genesets = desired_dataset, 
                   timepts = tps,
                   keep_top_edges = 1000, 
                   out_fname = paste0("GC_",type,"_",tp_name,"_lasso_hdi.txt"),
                   use.package.hdi = TRUE)

save(out,file=paste0("GC_",type,"_",tp_name,"_lasso_hdi.Rdata"))

out <- GCnet_l1var(dat.A = dat.A, dat.B = dat.B, 
                   genesets = desired_dataset, 
                   timepts = tps,
                   keep_top_edges = 1000, 
                   out_fname = paste0("GC_",type,"_",tp_name,"_lasso_JM.txt"),
                   use.package.hdi = FALSE)

save(out,file=paste0("GC_",type,"_",tp_name,"_lasso_JM.Rdata"))

