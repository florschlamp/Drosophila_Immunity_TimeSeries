# using different sets of genes
library(ppcor,lib.loc="~/Rlibs/")
source('functions.r')
load("InitialData.Rdata")

# START OF PARAMETERS
args <- commandArgs(trailingOnly=FALSE)
type = args[4]
start_tp = as.numeric(args[5])
end_tp = as.numeric(args[6])

print(paste0("number of cores: ",n_cores))

if(type == 'master_list'){
  desired_dataset = master_list
}

tps = start_tp:end_tp

tp_name = paste0(start_tp,"to",end_tp)

out <- GCnet_pwvar(dat.A = dat.A, dat.B = dat.B, 
                   genesets = desired_dataset, 
                   timepts = tps,
                   keep_top_edges = 1000, 
                   out_fname = paste0("GC_",type,"_",tp_name,"_pw.txt"))

save(out,file=paste0("GC_",type,"_",tp_name,"_pw.Rdata"))
