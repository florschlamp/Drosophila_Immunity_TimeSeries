#wrapper

import os,sys

window_size = int(sys.argv[1]) #number of time points -1 #### 3,4,5
types = sys.argv[2]

#for i in range(5,18):
for i in range(1,21-window_size):
#for i in range(1,5):
	start_tp=i
	end_tp=i+window_size
	name= "%s_%sto%s"%(types,start_tp,end_tp)
	if 'filtered' in types:
		codename= "%sF.%s.%s"%(types[0],window_size,start_tp)
	if 'filtered' not in types:
		codename= "%s.%s.%s"%(types[0],window_size,start_tp)
	if types == 'DE.short':
		codename= "Ds.%s.%s"%(window_size,start_tp)
	if types == 'DE.long':
		codename= "Dl.%s.%s"%(window_size,start_tp)

	os.system("sed -e 's/types=/types=%s/' < GCnet_pw_run.sh > tmp.sh"%(types))
	os.system("sed -e 's/start_tp=/start_tp=%s/' < tmp.sh > tmp2.sh"%(start_tp))
	os.system("sed -e 's/end_tp=/end_tp=%s/' < tmp2.sh > tmp3.sh"%(end_tp))
	os.system("sed -e 's/pw-/%s.pw/' < tmp3.sh > GCnet_pw_%s_run.sh"%(codename,name))
	os.system("qsub GCnet_pw_%s_run.sh"%(name))
	print name,"submitted"
	os.system('rm tmp*sh')
#for pvalue in (0.00001,0.000005,0.000001,0.0000005):
#	for i in range(1,18):
#		os.system("R -f GCnetwork_script_plotting.R %s %s %s %s"%(types,i,i+2,pvalue))
