# require(doMC)
# registerDoMC()
n_cores = 24 #to run in cluster

require(doParallel)
#if (Sys.info()[["sysname"]] == "Linux")
#  n_cores = as.numeric(system("nproc", intern = TRUE))
#if (Sys.info()[["sysname"]] == "Windows")
#  n_cores = as.numeric(Sys.getenv("NUMBER_OF_PROCESSORS"))
#if (Sys.info()[["sysname"]] == "Darwin")
#  n_cores = as.numeric(system("sysctl -n hw.ncpu",intern=TRUE))

cl <- makeCluster(n_cores)
registerDoParallel(cl)


options(cores = n_cores)
require(network)
require(gdata)
require(glasso)
require(ppcor)
require(fGarch)
require(quantreg)
source('lasso_inference.r')
require(hdi)

DEBUG = TRUE


read_data <- function(dir.input = './', geneset_name, dir.output = dir.input){
dat = read.table(paste(dir.input, '/', 'normalized_counts_filtered_', geneset_name, '.csv', sep='')
               , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE, sep=',')

dataset = list()
dataset$dat = data.matrix(dat)
dataset$gene_info = data.frame(gID = 1:length(rownames(dat)), flyBase_ID = rownames(dat), stringsAsFactors = FALSE)
sample_ID = colnames(dat)
dataset$sample_info = data.frame(sample_ID = substr(sample_ID, start=2, stop=nchar(sample_ID))
                               , group = substr(sample_ID, start=nchar(sample_ID), stop=nchar(sample_ID))
                               , stringsAsFactors = FALSE)

# ADD ZERO TO SAMPLE ID STARTING WITH 1-9
idx = nchar(dataset$sample_info$sample_ID) == 2
dataset$sample_info$sample_ID[idx] = paste("0", dataset$sample_info$sample_ID[idx], sep='')

dataset = order.genes(dataset, order.id = order(dataset$gene_info$flyBase_ID))
print(str(dataset))

# READ DETAILS OF 361 GENES
dat_gene = read.table(paste(dir.input, '/', 'List_of_immune_genes_', geneset_name, '.csv', sep='')
                    , header=TRUE, check.names=FALSE
                    , as.is=TRUE, sep=',')
names(dat_gene)[names(dat_gene) == "Fly Base ID"] = "flyBase_ID"
dat_gene = dat_gene[order(dat_gene$flyBase_ID),]

# merge with dataset of genes with functional information
# dataset = drop.genes(dataset, gene.id = !(dataset$gene_info$flyBase_ID %in% dat_gene$flyBase_ID))
tmp = merge(dataset$gene_info, dat_gene, all.x=TRUE, sort=TRUE)
if (sum(tmp$flyBase_ID!=dataset$gene_info$flyBase_ID))
    print('order mismatch during merge -- check data')
else
    dataset$gene_info = tmp

save(dataset, file=paste(dir.output, '/', geneset_name, '.RData', sep=''))

}




correlation=function(X) {

n = nrow(X); p = ncol(X)
Rm = apply(X, 1, FUN = mean)
correlation=array(0,c(p,2))

for (j in 1:p){
      correlation[j,1] = cor(X[,j],Rm)
	  correlation[j,2] = cor(X[-n,j],Rm[-1])
   }

   return(correlation)


}

es = function(X # n x p array of firm level characteristics
             , q = 0.01 # vector of quantiles desired
               ){
   n = nrow(X); p = ncol(X)
   Xq = apply(X, 2, FUN = function(v){return(quantile(v, prob = q))})
   es = rep(0, p)
   
   for (j in 1:p){
      es[j] = mean(X[X[,j] < Xq[j],j])
   }

   return(-es)
}


mes = function(X # n x p array of firm level characteristics
             , q = 0.05 # vector of quantiles desired
               ){
   n = nrow(X); p = ncol(X)
   Rm = apply(X, 1, FUN = mean)
   Rm_q = quantile(Rm, prob = q)
   mes = rep(0, p)
   
   for (j in 1:p){
      mes[j] = mean(X[Rm < Rm_q,j])
   }

   return(-mes)
}



covar = function(X   # n x p array of firm level characteristics
               , q = 0.05   # vector of quantiles desired
                 ){

   n = nrow(X); p = ncol(X)
   Rm = apply(X, 1, FUN = mean)
   Xmed = apply(X, 2, FUN = median)
   Xq = apply(X, 2, FUN = function(v){return(quantile(v, prob = q))})
   Delta_covar = rep(0, p)
    
   for (j in 1:p){
      ff = rq(Rm ~ X[,j], tau = q) # quantile Regress market return on firm return
      Delta_covar[j] = ff$coefficients[2]*(Xq[j] - Xmed[j])
   }
   
    # for (j in 1:p){
      # ffq = rq(Rm ~ X[,j], tau = q) # quantile Regress market return on firm return
      # ff = rq(Rm ~ X[,j], tau = 0.5) # quantile Regress market return on firm return
      # print(c(ffq,ff))
      # Delta_covar[j] = ffq$coefficients[2]*Xq[j] -ff$coefficients[2]* Xmed[j]
   # }
return(-Delta_covar)
}

## calculate beta of an asset
b = function(X # n x p array of firm level characteristics
                ){
   n = nrow(X); p = ncol(X)
   Rm = apply(X, 1, FUN = mean)
   s=var(Rm)
   b = rep(0, p)
   
   for (j in 1:p){
      b[j] =cov(X[,j],Rm)/s
   }

   return(b)
}

impulse = function(A  # p x p matrix
                 , X0 = rep(0, nrow(A)) # p-vector of return at time 0
                 , P0 # p-vector of price at time 0
                 , shout # p-vector of number of shares outstanding 
                 , H  # horizon
                 , shock # p-vector of shocks to firms
                 , distress_thresh # scalar, fraction
				 ){
    p = nrow(A)
    P = array(0, c(p, H+1)); P[,1] = P0
    mcap = array(0, c(p, H+1)); #mcap[,1]=P0*shout
    loss = array(0, c(p, H))
    X = array(0, c(p, 1+H)); X[,1] = shock + X0 ; mcap[,1]=P0*(1+X[,1])*shout
    loss = array(0, c(p, H))
	#flag=rep(0,p)
	#flag[X[,1]<=-1]=1
	for (h in 1:H){
       X[,h+1] = A %*% X[,h]
	   #flag[X[,h+1]<=-1]=1
	   #X[flag==1,h+1]=-1
	   P[,h+1] = P[,h]*(X[,h+1]+1)
       mcap[,h+1] = P[,h+1]*shout
       loss[,h] = mcap[,1] - mcap[,h+1]
    }

    traj_loss = apply(loss, 2, FUN=sum)
    traj_distress_count = apply(X[,-1] < distress_thresh, 2, FUN = sum)

return(list(total_loss = traj_loss, total_distress = traj_distress_count, loss=loss, P=P,Ret=X))
}


# impute missing values in a vector with median
impute_median = function(v){
id = is.na(v)

if (sum(id))
   v[id] = median(v[!id], na.rm=TRUE)
return(v)
}

# pairwise correlation
net_corr = function(X
                  , method='pearson'){
   n = nrow(X)
   p = ncol(X)

   r = array(0, c(p, p))
   pval = array(0, c(p, p))

   for (i in 1:(p-1)){
      for (j in (i+1):p){
         ff = cor.test(X[,i], X[,j]
                     , method = method)
         r[i,j] = ff$estimate
         pval[i,j] = ff$p.value
      }
   }
#   r = r + t(r); diag(r) = 1
#   pval = pval + t(pval); diag(pval) = 0
   lowerTriangle(r, diag=FALSE) <- upperTriangle(r, diag=FALSE, byrow=TRUE); diag(r) = 1
   lowerTriangle(pval, diag=FALSE) <- upperTriangle(pval, diag=FALSE, byrow=TRUE); diag(pval) = 0

   return(list(adj = r, pval = pval))
}

# pairwise correlation with parallelization
net_corr_parr = function(X
                       , method = 'pearson'){
   n = nrow(X)
   p = ncol(X)

   tmp = matrix(1:(p^2), nrow=p)
   ind = lowerTriangle(tmp, diag = FALSE)


   out <- foreach(kk = ind
                , .combine = rbind
                , .multicombine=TRUE)%dopar%{
      j = floor((kk-1)/p)+1
      i = kk%%p; if (!i) i = p

      r.p = matrix(0, nrow=1, ncol = 2)
      f = cor.test(X[,i], X[,j], method = method)
      r.p[1,1] = f$estimate
      r.p[1,2] = f$p.value

      r.p
   }
   r = array(0, c(p, p))
   lowerTriangle(r, diag=FALSE) <- out[,1]
#   r = r+t(r); diag(r) = 1
   upperTriangle(r, diag=FALSE) <- lowerTriangle(r, diag=FALSE, byrow=TRUE); diag(r) = 1

   pval = array(0, c(p, p))
   lowerTriangle(pval, diag=FALSE) <- out[,2]
#   pval =pval + t(pval); diag(pval) = 0
   upperTriangle(pval, diag=FALSE) <- lowerTriangle(pval, diag=FALSE, byrow=TRUE); diag(pval) = 0
   
   return(list(adj = r, pval = pval))
}

# graphical lasso
net_pcorr = function(X
                   , method = 'DGlasso'){ # method in c('DGlasso', 'pcor')
   if (method == 'DGlasso')
      return(DGlasso.v1(X))

   else if (method == 'pcor'){
      n = nrow(X)
      p = ncol(X)
      if (n <= p){
          print('no. of obs. less than no. of variables - cannot calculate partial correlation !!!')
          exit
      }
      else{
          ff = pcor(X, method = 'pearson')
          return(list(adj = ff$estimate, pval = ff$p.value))
      }
   }
}

# pairwise VAR
net_pwvar_parr = function(X, XX = NULL, YY = NULL){
   if (!is.null(X)){
   n = nrow(X)
   p = ncol(X)
   XX = X[1:(n-1),]
   YY = X[2:n,]
   }
   if (!(is.null(XX)|is.null(YY))){
   n = nrow(XX)
   p = ncol(XX)
   }

   tmp = matrix(1:(p^2), nrow=p)
   ind = lowerTriangle(tmp, diag = FALSE)


   out <- foreach(kk = ind
                , .combine = rbind
                , .multicombine=TRUE)%dopar%{
      j = floor((kk-1)/p)+1
      i = kk%%p; if (!i) i = p

      ff1 = lm(YY[,i] ~  XX[,i] + XX[,j])  # 0 + 
      ff2 = lm(YY[,j] ~  XX[,i] + XX[,j]) # 0 +

      tmp = matrix(c(summary(ff1)$coefficients[3, c(1,4)]
      , summary(ff2)$coefficients[2, c(1,4)]), nrow=1, ncol=4)
      tmp
   }

 # diagonals are zero by construction here   
   if (!DEBUG){ # old version - fill upper and lower triangles separately; delete later !!
   adj1 = array(0, c(p, p)); adj2 = adj1
   lowerTriangle(adj1, diag=FALSE) <- out[,1]
   lowerTriangle(adj2, diag=FALSE) <- out[,3]

   pval1 = array(0, c(p, p)); pval2 = pval1
   lowerTriangle(pval1, diag=FALSE) <- out[,2]
   lowerTriangle(pval2, diag=FALSE) <- out[,4]
   

   return(list(adj = adj1+t(adj2)
              , pval = pval1+t(pval2)
               )
          )
   }

   if (DEBUG){ # new version of filling lower and upper triangles
   adj = array(0, c(p, p))
   lowerTriangle(adj, diag=FALSE) <- out[,1]
   upperTriangle(adj, diag=FALSE, byrow=TRUE) <- out[,3]

   pval = array(0, c(p, p)); diag(pval) = 0
   lowerTriangle(pval, diag=FALSE) <- out[,2]
   upperTriangle(pval, diag=FALSE, byrow=TRUE) <- out[,4]

   return(list(adj=adj, pval=pval))
   }
}

# overall sparse VAR
net_l1var_parr= function(X, net_eps = FALSE, XX=NULL, YY=NULL
    , thresh.screening = 0.01){   # variables with pvaues below this threshold are used to refit and calculate residuals
   if (!is.null(X)){
   n=nrow(X)
   p=ncol(X)
   XX=X[1:(n-1),]
   YY=X[2:n,]
   }
   if (!(is.null(XX)|is.null(YY))){
   n=nrow(XX)
   p=ncol(XX)
   }

   XX=scale(XX, center=TRUE, scale=TRUE)
# print('check1')
# print(p)
# print(n)
   l = median(apply(YY, 2, FUN=sd))*sqrt(log(p)/(n-1))
# print('check2')

   f=list()
   f<- foreach(j=1:p, .multicombine=TRUE) %dopar%{
          #   f[[j]]=glmnet(XX, YY[,j], lambda=l)
          #   f[[j]]=SSLasso(XX, YY[,j], verbose=TRUE)
source('lasso_inference.r')
             SSLasso(XX, YY[,j], verbose=FALSE)
      }

   adj = matrix(0, p, p)
   pval = adj
   teststat = adj

   for (i in 1:p){
          adj[i,] = f[[i]]$unb.coef
          pval[i,] = f[[i]]$pvals
		  teststat[i,] = f[[i]]$test.statistic
   }

   if (net_eps){
   E=YY
   for (j in 1:p){
#       print(j)
       idx = which(pval[j,] < thresh.screening)
       if (length(idx))
             E[,j] = lm(YY[,j] ~ 0 + XX[,idx])$residuals
   }

   fres=net_pcorr(X = scale(E, center=TRUE, scale=TRUE), method='DGlasso')
   }

   if (net_eps)
       return(list(adj=adj, pval=pval, test_statistic = teststat, adj.e = fres$adj, pval.e = fres$pval))
   else
       return(list(adj=adj, pval=pval, test_statistic = teststat))
}

# overall sparse VAR
net_l1var_parr_hdi= function(X, net_eps = FALSE, XX=NULL, YY=NULL
                         , thresh.screening = 0.01){   # variables with pvaues below this threshold are used to refit and calculate residuals
  if (!is.null(X)){
    n=nrow(X)
    p=ncol(X)
    XX=X[1:(n-1),]
    YY=X[2:n,]
  }
  if (!(is.null(XX)|is.null(YY))){
    n=nrow(XX)
    p=ncol(XX)
  }
  
  XX=scale(XX, center=TRUE, scale=TRUE)
  l = median(apply(YY, 2, FUN=sd))*sqrt(log(p)/(n-1))
  
  f=list()
  f<- foreach(j=1:p, .multicombine=TRUE) %dopar%{
    #   f[[j]]=glmnet(XX, YY[,j], lambda=l)
    #   f[[j]]=SSLasso(XX, YY[,j], verbose=TRUE)
    # source('lasso_inference.r')
    library(hdi)
    # print(dim(XX))
    # print(dim(YY))
    print(j)
    ff <- lasso.proj(x=XX, y=YY[,j], parallel = FALSE, standardize = FALSE, multiplecorr.method = 'none')
    ff$pval
  }
  
  adj = matrix(0, p, p)
  pval = adj
  teststat = adj
  
  for (i in 1:p){
    adj[i,] = 0 # f[[i]]$unb.coef
    pval[i,] = f[[i]]
    teststat[i,] = 0 # f[[i]]$test.statistic
  }
  
  if (net_eps){
    E=YY
    for (j in 1:p){
      #       print(j)
      idx = which(pval[j,] < thresh.screening)
      if (length(idx))
        E[,j] = lm(YY[,j] ~ 0 + XX[,idx])$residuals
    }
    
    fres=net_pcorr(X = scale(E, center=TRUE, scale=TRUE), method='DGlasso')
  }
  
  if (net_eps)
    return(list(adj=adj, pval=pval, test_statistic = teststat, adj.e = fres$adj, pval.e = fres$pval))
  else
    return(list(adj=adj, pval=pval, test_statistic = teststat))
}


fit2graph = function(adj, pval
                   , method='BH'
                   , thresh.cutoff = 0.01
                   , convert2undirected = TRUE  # change directed graphs to undirected
                   , wtd_adj = FALSE  # return graph with edge weights
                   , combine.directed.edges = 'and'){ # either 'and' or 'or'
   p = nrow(adj)

   grf = array(FALSE, c(p, p))
#   lowerTriangle(pval, diag=FALSE) <- p.adjust(lowerTriangle(pval, diag=FALSE), method=method)
#   upperTriangle(pval, diag=FALSE) <- p.adjust(upperTriangle(pval, diag=FALSE), method=method)

   tmp = c(lowerTriangle(pval, diag=FALSE), upperTriangle(pval, diag=FALSE))
   tmp = p.adjust(tmp, method=method)
   lowerTriangle(pval, diag=FALSE) <- tmp[seq(length(tmp)/2)]
   upperTriangle(pval, diag=FALSE) <- tmp[-seq(length(tmp)/2)]
   rm(tmp)

   if (any(pval!=t(pval)) & convert2undirected == TRUE){ # for a directed graph, use and/or rule to make it an undirected graph

   if (combine.directed.edges == 'and'){
       for (i in 1:(p-1)){
           for (j in (i+1):p){
               tmp = max(pval[i,j], pval[j,i])
               pval[i,j] = tmp
               pval[j,i] = tmp
           }
       }
   }

   if (combine.directed.edges == 'or'){
       for (i in 1:(p-1)){
           for (j in (i+1):p){
               tmp = min(pval[i,j], pval[j,i])
               pval[i,j] = tmp
               pval[j,i] = tmp
           }
       }
   }

   }  # end if (any(pval!=t(pval)) ... )

   if (wtd_adj == FALSE){
   grf= (pval < thresh.cutoff)+0
   diag(grf)=0  # make diagonal zero i.e no significant edges in diagonal
   }
   else{ # leave the edge weights in the graph, no self-loops though
   grf = adj*(pval < thresh.cutoff)+0
   diag(grf)=0
   }

return(grf)
}

net_plot = function(adj
                  , coord=NULL
                  , node_label
                  , node_color='black'
                  , cex_node_label = 0.7
                  , edge_lwd = 1
                  , edge_color = 'black'
                  , plot_main = 'Network'
                  , plot_sub = 'Sectors'
                  , mode = 'circle'
                  , ...) {
plot(network(adj)
   , label = node_label
   , mode = mode
   , coord = coord
   , vertex.cex = 0, label.cex = cex_node_label
   , label.pos = 6
   , label.col = node_color
   , edge.lwd = edge_lwd
   , edge.col = edge_color
   , main = plot_main
   , sub = plot_sub
   , ...
     )   
}


fit.garch = function(X){
   n = nrow(X)
   p = ncol(X)
   
   out <- foreach(i=1:p
                , .combine=cbind
                , .multicombine=TRUE)%dopar%{
				tmp=X[,i]
				if(sum(is.na(tmp))!=0)
            tmp[which(is.na(tmp))]=median(tmp, na.rm=TRUE)

      garchest<- garchFit(~garch(1,1)
                        , data=tmp
                        , cond.dist = c("snorm")
                        , include.mean = TRUE
                        , include.skew=FALSE
                        , algorithm = c("nlminb")
                        , hessian = c("ropt")
                        , trace = FALSE
                         )
      garchest@residuals/garchest@sigma.t
      }
return(out)
}



DGlasso.v1 = function(X, lambda = NULL, quiet = TRUE){ # accepts scaled matrix X only
    n = nrow(X)
    p = ncol(X)

    if (is.null(lambda)){
        lambda = sqrt(log(p)/n)
    }

    Sigma.hat_X= var(X)

    if (!quiet){print('fit glasso')}
    Theta.hat_glasso = glasso(s=Sigma.hat_X, rho=lambda, penalize.diagonal=FALSE)$wi

    if (!quiet){cat('done ... \n \n de-biasing ... \n')}
    temp.mat = Sigma.hat_X - chol2inv(chol(Theta.hat_glasso))
    temp.vec = as.vector(Theta.hat_glasso %*% temp.mat %*% t(Theta.hat_glasso))
    T.hat = as.vector(Theta.hat_glasso) - temp.vec
    if (!quiet){print('done')}

    r.mat=matrix(T.hat, nrow=p)
    T.hat.vec = upperTriangle(r.mat, diag=FALSE)

    sigma.hat2 = array(0,c(p,p))

    for (i in 1:(p-1)){
        for (j in (i+1):p){
            sigma.hat2[i,j] = Theta.hat_glasso[i,j]^2+Theta.hat_glasso[i,i]*Theta.hat_glasso[j,j]
        }
    }

    sigma.hat2.vec = upperTriangle(sigma.hat2,diag=FALSE)
    test.stat = sqrt(n)*T.hat.vec/sqrt(sigma.hat2.vec)
    pvals.vec = 2*(1-pnorm(abs(test.stat)))

    pvals = array(0, c(p, p))
    upperTriangle(pvals) <- pvals.vec
    pvals = pvals + t(pvals)
    
    for (i in 1:p)
        for (j in 1:p)
            r.mat[i,j]=sign(r.mat[i,j])*min(abs(r.mat[i,j])/sqrt(r.mat[i,i]*r.mat[j,j]), 1)

    return(list(adj = r.mat, pval=pvals))
}


################################################
##################################################


draw_panel_net = function(X, firmnames, timept, colseq, varname){


  # fit bivariate VARs as in Bilio
  ff = net_pwvar_parr(X)

  # fig 1.1: Bilio VAR - no FDR correction
  net_plot(fit2graph(ff$adj, ff$pval
                   , method = 'none'
                   , thresh.cutoff = 0.05
                   , combine.directed.edges = 'or')
         , node_label = firmnames
         , node_color = colseq[[i]]
         , plot_main = paste(varname,': Pairwise VAR [No FDR]')
         , plot_sub = paste(timept[1], timept[n], sep=' : '))

  # fig 1.2: Bilio VAR - FDR = 0.2
  net_plot(fit2graph(ff$adj, ff$pval
                   , method = 'BH'
                   , thresh.cutoff = 0.2
                   , combine.directed.edges = 'or')
         , node_label = firmnames
         , node_color = colseq[[i]]
         , plot_main = paste(varname, ': Pairwise VAR [FDR = 0.20]')
         , plot_sub = paste(timept[1], timept[n], sep=' : '))

  # fig 1.3: Bilio VAR - FDR = 0.1
  net_plot(fit2graph(ff$adj, ff$pval
                   , method = 'BH'
                   , thresh.cutoff = 0.1
                   , combine.directed.edges = 'or')
         , node_label = firmnames
         , node_color = colseq[[i]]
         , plot_main = paste(varname, ': Pairwise VAR [FDR = 0.10]')
         , plot_sub = paste(timept[1], timept[n], sep=' : '))

  ff = net_l1var_parr(X, net_eps = TRUE, thresh.screening=0.01)

  # fig 1.4: l1-VAR - transition matrix (FDR = 0.2)
  net_plot(fit2graph(ff$adj, ff$pval
                   , method = 'BH'
                   , thresh.cutoff = 0.2
                   , combine.directed.edges = 'or')
         , node_label = firmnames
         , node_color = colseq[[i]]
         , plot_main = paste(varname, ': l1-VAR Transition [FDR = 0.2]')
         , plot_sub = paste(timept[1], timept[n], sep=' : '))

  # fig 1.5: l1-VAR - Sigma_epsilon (FDR = 0.2)
  net_plot(fit2graph(ff$adj.e, ff$pval.e
                   , method = 'BH'
                   , thresh.cutoff = 0.2
                   , combine.directed.edges = 'or')
         , node_label = firmnames
         , node_color = colseq[[i]]
         , plot_main = paste(varname, ': l1-VAR Residual Graph [FDR = 0.2]')
         , plot_sub = paste(timept[1], timept[n], sep=' : '))

#############################################################

}


shift_y = function(dat){
dat = dat[order(dat$cusip, dat$yr),]
firmlist = unique(dat$cusip)
print(paste('no. of firms = ', length(firmlist)))
dat$DELISTCD_shifted <- NA

ct=1
for (ff in firmlist){
#    print(ct)
	id = which(dat$cusip == ff)
	
	y = dat$DELISTCD[id]
	tmp = length(y)
	
	if (tmp>1)
		dat$DELISTCD_shifted[id[1:(tmp-1)]] = y[2:tmp]
    ct = ct+1
}
return(dat)
}

tran_prob <- function(x, y, cutoff = -0.1){
  n = length(x); if (length(y)!=n){stop('two time series do not have equal length!!')}
  if (sum(is.na(x))|sum(is.na(y))){stop('missing values in at least one of the time series!!')}

  x = (x < cutoff); y = (y < cutoff)

  r_xx = sum(x[1:(n-1)]&(!x[2:n]))/(n-1)
  r_xy = sum(x[1:(n-1)]&(!y[2:n]))/(n-1)
  r_yx = sum(y[1:(n-1)]&(!x[2:n]))/(n-1)
  r_yy = sum(y[1:(n-1)]&(!y[2:n]))/(n-1)

  return(array(c(r_xx, r_yx, r_xy, r_yy), c(2,2)))
}

###########################################
# FUNCTIONS FROM ARUN: MANIPULATE DATASET OBJECTS
###########################################

drop.genes = function(dataset, gene.id = NULL){
if(is.null(gene.id)){print("no gene selected")}
else{
dataset[["gene_info"]] = dataset[["gene_info"]][!gene.id,]
dataset[["dat"]] = dataset[["dat"]][!gene.id,]

if(!is.null(dataset[["result"]])){
	for (res.id in (names(dataset[["result"]]))){
		dataset[["result"]][[res.id]] = dataset[["result"]][[res.id]][!gene.id,]
	}
}

}
return(dataset)
}

order.genes = function(dataset, order.id = NULL){
if(is.null(order.id)){print("no gene selected")}
else{
dataset[["gene_info"]] = dataset[["gene_info"]][order.id,]
dataset[["dat"]] = dataset[["dat"]][order.id,]

if(!is.null(dataset[["result"]])){
	for (res.id in (names(dataset[["result"]]))){
		dataset[["result"]][[res.id]] = dataset[["result"]][[res.id]][order.id,]
	}
}

}
return(dataset)
}


order.samples = function(dataset, order.id = NULL){
	if(is.null(order.id)){print("no samples selected")}
	else{
	dataset[["sample_info"]] = dataset[["sample_info"]][order.id,]
	dataset[["dat"]] = dataset[["dat"]][,order.id]
	}
return(dataset)
}


drop.samples = function(dataset, sample.id = NULL){
if(is.null(sample.id)){print("no sample selected")}
else{
dataset[["sample_info"]] = (dataset[["sample_info"]][!sample.id,])
dataset[["dat"]] = (dataset[["dat"]][,!sample.id])
}
return(dataset)
}

