
library("reshape2")
#source('functions.r')

dat_norm <- read.table('normalized_counts_gene-names.csv',
                       header=TRUE, row.names=1, as.is=TRUE, 
                       check.names=FALSE, sep=',')

dat = data.matrix(dat_norm)
dat = dat[-which(rownames(dat) %in% 'CG31775'),] #filter copy gene out
dat = dat[,-4]
dat.A = dat[,1:20]
dat.B = dat[,21:40]


load("tentative_subset.RData") # 551 genes
DE_729 <- read.csv("DE_729.csv",header=F)$V2
load("Gene_Master_Summary_new.RData")

small_t <- data.frame(genes=my_data_final$GeneSymbol, GO_IDs=my_data_final$GO_IDs)
small_t <- small_t[complete.cases(small_t), ]
genes_with_function <- small_t$genes

SUBSET_with_function <- TENTATIVE_SUBSET[TENTATIVE_SUBSET %in% genes_with_function]
SUBSET_w_func_logFC1 <- SUBSET_with_function[SUBSET_with_function %in% DE_729] 
length(SUBSET_w_func_logFC1)

subset_my_data_table <- my_data_final[my_data_final$GeneSymbol %in% SUBSET_w_func_logFC1,]
#write.csv(subset_my_data_table,file="subset_of_master_table_258.csv")

master_list <- SUBSET_w_func_logFC1

save(master_list,dat.A,dat.B,
     file="InitialData.Rdata")



