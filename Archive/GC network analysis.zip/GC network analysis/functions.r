require(limma)
require(edgeR)
require(splines)
require(DESeq2)
require(gdata)
require(reshape2)
require(ggplot2)
source('library.r')


generate_initial_data <- function(dat.A # a pxT matrix of normalized counts from replicate A [dim(dat.A) = dim(dat.B)]
                     , dat.B # a pxT matrix of normalized counts from replicate B [dim(dat.A) = dim(dat.B)]
					 , timepts = 1:4 # set of time points to use in GC analysis -- a numeric vector 
					 , genesets # a character vector with the names of genes to be analyzed
					  ){
if (any(dim(dat.A)!=dim(dat.B))){stop('Error: dat.A and dat.B have different dimensions')}
if (any(rownames(dat.A)!=rownames(dat.B))){stop('Error: genes are not in same order!!!')}

dat.A = dat.A[rownames(dat.A) %in% genesets,]
dat.B = dat.B[rownames(dat.B) %in% genesets,]

tt = length(timepts)
p = nrow(dat.A)
gene_label = rownames(dat.A)

XX = t(cbind(dat.A[,timepts[1:(tt-1)]], dat.B[,timepts[1:(tt-1)]]))
YY = t(cbind(dat.A[,timepts[2:tt]], dat.B[,timepts[2:tt]]))

return(list(X=XX, Y=YY))
}


# takes as input two pxT matrices dat.A and dat.B of same size
# containing normalized log-counts from replicates A and B, and gene names (in same order) on their rows
# and a subset of genes;
# Forms network of significant GC relationships between each pair of genes;
# outputs a list of two pxp matrices with GC estimates and pvalues
# optionally, writes top XX significant edges in a tab-separated .txt file
GCnet_pwvar <- function(dat.A # a pxT matrix of normalized counts from replicate A [dim(dat.A) = dim(dat.B)]
                     , dat.B # a pxT matrix of normalized counts from replicate B [dim(dat.A) = dim(dat.B)]
					 , timepts = 1:4 # set of time points to use in GC analysis -- a numeric vector 
					 , genesets # a character vector with the names of genes to be analyzed
					 , out_fname = NULL
					 , keep_top_edges = 500
					  ){
if (any(dim(dat.A)!=dim(dat.B))){stop('Error: dat.A and dat.B have different dimensions')}
if (any(rownames(dat.A)!=rownames(dat.B))){stop('Error: genes are not in same order!!!')}

dat.A = dat.A[rownames(dat.A) %in% genesets,]
dat.B = dat.B[rownames(dat.B) %in% genesets,]

tt = length(timepts)
p = nrow(dat.A)
gene_label = rownames(dat.A)

XX = t(cbind(dat.A[,timepts[1:(tt-1)]], dat.B[,timepts[1:(tt-1)]]))
YY = t(cbind(dat.A[,timepts[2:tt]], dat.B[,timepts[2:tt]]))

ff = net_pwvar_parr(X = NULL
                  , XX = XX 
                  , YY = YY 
				   )
rownames(ff$adj) <- gene_label; rownames(ff$pval) <- gene_label
colnames(ff$adj) <- gene_label; colnames(ff$pval) <- gene_label

# write networks in a table
rowlabs = matrix(gene_label, nrow=p, ncol=p)
collabs = t(rowlabs)

out = data.frame(Gene1 = c(upperTriangle(rowlabs, diag=FALSE, byrow=TRUE)
                         , lowerTriangle(rowlabs, diag=FALSE, byrow=FALSE))
         , Gene2 = c(upperTriangle(collabs, diag=FALSE, byrow=TRUE)
		           , lowerTriangle(collabs, diag=FALSE, byrow=FALSE))
		 , edgewt = c(upperTriangle(ff$adj, diag=FALSE, byrow=TRUE)
		           , lowerTriangle(ff$adj, diag=FALSE, byrow=FALSE))
		 , pval = c(upperTriangle(ff$pval, diag=FALSE, byrow=TRUE)
		           , lowerTriangle(ff$pval, diag=FALSE, byrow=FALSE))
		 , stringsAsFactors=FALSE
		   )
		   
out$adjpval.BH = p.adjust(out$pval, method='BH')
out$adjpval.BY = p.adjust(out$pval, method='BY')
out$adjpval.bonferroni = p.adjust(out$pval, method='bonferroni')

out = out[order(out$pval),]

if (!is.null(out_fname)){
  out = out[1:keep_top_edges,]
  write.table(out, sep='\t', file = out_fname, row.names = FALSE) 
}

return(ff)
}



GCnet_l1var <- function(dat.A # a pxT matrix of normalized counts from replicate A [dim(dat.A) = dim(dat.B)]
                        , dat.B # a pxT matrix of normalized counts from replicate B [dim(dat.A) = dim(dat.B)]
                        , timepts = 1:4 # set of time points to use in GC analysis -- a numeric vector 
                        , genesets # a character vector with the names of genes to be analyzed
                        , out_fname = NULL
                        , keep_top_edges = 500
                        , use.package.hdi = FALSE
){
  if (any(dim(dat.A)!=dim(dat.B))){stop('Error: dat.A and dat.B have different dimensions')}
  if (any(rownames(dat.A)!=rownames(dat.B))){stop('Error: genes are not in same order!!!')}
  
  dat.A = dat.A[rownames(dat.A) %in% genesets,]
  dat.B = dat.B[rownames(dat.B) %in% genesets,]
  
  tt = length(timepts)
  p = nrow(dat.A)
  gene_label = rownames(dat.A)
  
  XX = t(cbind(dat.A[,timepts[1:(tt-1)]], dat.B[,timepts[1:(tt-1)]]))
  YY = t(cbind(dat.A[,timepts[2:tt]], dat.B[,timepts[2:tt]]))
  
  # print(dim(XX))
  # print(dim(YY))
  
  if (use.package.hdi == FALSE){
  ff = net_l1var_parr(X = NULL
                      , XX = XX 
                      , YY = YY 
  )
  }
  
  if (use.package.hdi == TRUE){
    # print(dim(XX))
    # print(dim(YY))
    
    # for (j in 1:p){
    #   print(j)
    #   ff = lasso.proj(x=XX, y=as.vector(YY[,j]), parallel = FALSE, standardize = FALSE, multiplecorr.method = 'none')
    # print(ff$pval)
    # }
    
    ff = net_l1var_parr_hdi(X = NULL
                        , XX = XX
                        , YY = YY
    )
  }
  
  rownames(ff$adj) <- gene_label; rownames(ff$pval) <- gene_label; 
  rownames(ff$test_statistic) <- gene_label
  colnames(ff$adj) <- gene_label; colnames(ff$pval) <- gene_label
  colnames(ff$test_statistic) <- gene_label
  
  # write networks in a table
  rowlabs = matrix(gene_label, nrow=p, ncol=p)
  collabs = t(rowlabs)
  
  
  
  out = data.frame(Gene1 = c(upperTriangle(rowlabs, diag=FALSE, byrow=TRUE)
                             , lowerTriangle(rowlabs, diag=FALSE, byrow=FALSE))
                   , Gene2 = c(upperTriangle(collabs, diag=FALSE, byrow=TRUE)
                               , lowerTriangle(collabs, diag=FALSE, byrow=FALSE))
                   , edgewt = c(upperTriangle(ff$adj, diag=FALSE, byrow=TRUE)
                                , lowerTriangle(ff$adj, diag=FALSE, byrow=FALSE))
                   , pval = c(upperTriangle(ff$pval, diag=FALSE, byrow=TRUE)
                              , lowerTriangle(ff$pval, diag=FALSE, byrow=FALSE))
                   , test_statistic = c(upperTriangle(ff$test_statistic, diag=FALSE, byrow=TRUE)
                              , lowerTriangle(ff$test_statistic, diag=FALSE, byrow=FALSE))
                   , stringsAsFactors=FALSE
  )
  
  out$adjpval.BH = p.adjust(out$pval, method='BH')
  out$adjpval.BY = p.adjust(out$pval, method='BY')
  out$adjpval.bonferroni = p.adjust(out$pval, method='bonferroni')
  
  out = out[order(out$pval, -out$test_statistic),]
  
  if (!is.null(out_fname)){
    out = out[1:keep_top_edges,]
    write.table(out, sep='\t', file = out_fname) 
  }
  
  return(ff)
}

network2table <- function(out_GCnet){

  ff = out_GCnet
  gene_label = rownames(ff$pval)
  p = nrow(ff$pval)
  
  # write networks in a table
  rowlabs = matrix(gene_label, nrow=p, ncol=p)
  
  collabs = t(rowlabs)
  
  out = data.frame(Gene1 = c(upperTriangle(rowlabs, diag=FALSE, byrow=TRUE)
                             , lowerTriangle(rowlabs, diag=FALSE, byrow=FALSE))
                   , Gene2 = c(upperTriangle(collabs, diag=FALSE, byrow=TRUE)
                               , lowerTriangle(collabs, diag=FALSE, byrow=FALSE))
                   , edgewt = c(upperTriangle(ff$adj, diag=FALSE, byrow=TRUE)
                                , lowerTriangle(ff$adj, diag=FALSE, byrow=FALSE))
                   , pval = c(upperTriangle(ff$pval, diag=FALSE, byrow=TRUE)
                              , lowerTriangle(ff$pval, diag=FALSE, byrow=FALSE))
                   , test_statistic = c(upperTriangle(ff$test_statistic, diag=FALSE, byrow=TRUE)
                              , lowerTriangle(ff$test_statistic, diag=FALSE, byrow=FALSE))
                   , stringsAsFactors=FALSE
  )
  

  
  out$adjpval.BH = p.adjust(out$pval, method='BH')
  out$adjpval.BY = p.adjust(out$pval, method='BY')
  out$adjpval.bonferroni = p.adjust(out$pval, method='bonferroni')
  
  out = out[order(out$pval, -out$test_statistic),]
  
return(out)
}






plot_GCnet <- function(output_GCnet
                   , p.adjust.method = 'none' # choose from 'none', 'BH', 'bonferroni'
				   , pval.cut = 0.05 # only show edges with adjusted pvalue less than this cutoff
                   , ... # additional output to net_plot 
					){
ff = output_GCnet
gene_label = rownames(ff$adj)					
grf = fit2graph(ff$adj, ff$pval, method=p.adjust.method, thresh.cutoff = pval.cut, convert2undirected = FALSE, combine.directed.edges = 'or')
rownames(grf) <- gene_label; colnames(grf) <- gene_label

# only keep imp genes
drop.row = which(rowSums(grf)==0)
drop.col = which(colSums(grf)==0)
drop.genes = intersect(drop.row, drop.col)
grf = grf[-drop.genes, -drop.genes]

net_plot(t(grf), node_label = rownames(grf), usearrows = TRUE, arrowhead.cex = 0.5, ...)
}

##### example call ######
if (FALSE){
dat = read.csv('new_normalized_counts.csv', header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)
genelist.bioproc = read.csv('all_genes_biological-processp.value_0.1_score_1_2tp.csv'
                          , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
genelist.cellcomp = read.csv('all_genes_cellular-compartmentp.value_0.1_score_0.5_2tp.csv'
                          , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
genelist.molfunc = read.csv('all_genes_molecular-function_p.value_0.1_score_0.6_2tp.csv'
                          , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
dat = data.matrix(dat)
dat = dat[,-4]

dat.A = dat[,1:20]
dat.B = dat[,21:40]

out <- GCnet_pwvar(dat.A = dat.A, dat.B = dat.B, genesets = genelist.bioproc[1:20], keep_top_edges = 100, out_fname = 'GC_bioproc.txt')

pdf('GCnet_bioproc.pdf'
  , height = 15, width = 15)
plot_GCnet(out, pval.cut = 0.007, p.adjust.method='none')
dev.off()

}

# ANOTHER example call -- lasso
if (FALSE){
  dat = read.csv('new_normalized_counts.csv', header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)
  genelist.bioproc = read.csv('all_genes_biological-processp.value_0.1_score_1_2tp.csv'
                              , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
  genelist.cellcomp = read.csv('all_genes_cellular-compartmentp.value_0.1_score_0.5_2tp.csv'
                               , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
  genelist.molfunc = read.csv('all_genes_molecular-function_p.value_0.1_score_0.6_2tp.csv'
                              , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
  dat = data.matrix(dat)
  dat = dat[,-4]
  
  dat.A = dat[,1:20]
  dat.B = dat[,21:40]
  
  out <- GCnet_l1var(dat.A = dat.A, dat.B = dat.B
                     , genesets = genelist.bioproc
                     , keep_top_edges = 10000, out_fname = 'GC_bioproc_lasso.txt')
  
  pdf('GCnet_bioproc_lasso.pdf'
      , height = 15, width = 15)
  plot_GCnet(out, pval.cut = 0.0001, p.adjust.method='none')
  dev.off()
  
}


# Documentation of input variables
# all_genes:
# no_genes: 
# gene_from, gene_to: 
compare_edge_random_geneset <- function(all_genes, no_genes = 200-2, gene_from, gene_to, no_rep = 10
                                      , dat.A, dat.B, ... ){

rk_table = array(0, c(no_rep, 3))
colnames(rk_table) = c('pwvar', 'l1var_hdi', 'l1var_JM')

store_genes = array("", c(no_rep, no_genes+2))

all_genes_except_from_to = setdiff(all_genes, c(gene_from, gene_to))
									  
for (rr in 1:no_rep){	
print(paste0('rep = ', rr))								  
genelist.random<-c(sample(all_genes_except_from_to,no_genes),gene_from, gene_to)

store_genes[rr,] = genelist.random
save(store_genes, file='random_genesets.RData')

dat.A.sub <- dat.A[rownames(dat.A) %in% genelist.random,]
dat.B.sub <- dat.B[rownames(dat.B) %in% genelist.random,]

if (any(rownames(dat.A.sub) !=rownames(dat.B.sub))){print('error: gene names in two replicates not matching !!')}

out <- GCnet_pwvar(dat.A = dat.A.sub, dat.B = dat.B.sub,
                   genesets = genelist.random, ... 
                   )
out$test_statistic <- array(0, c(no_genes+2, no_genes+2))				   
out_table <- network2table(out)
rk_table[rr, 1] <- which(out_table$Gene1 == gene_to & out_table$Gene2 == gene_from)

out <- GCnet_l1var(dat.A = dat.A.sub, dat.B = dat.B.sub,
                   genesets = genelist.random, use.package.hdi = TRUE
				   , ...)
out_table <- network2table(out)
rk_table[rr, 2] <- which(out_table$Gene1 == gene_to & out_table$Gene2 == gene_from)


out <- GCnet_l1var(dat.A = dat.A.sub, dat.B = dat.B.sub,
                   genesets = genelist.random, use.package.hdi = FALSE
				   , ...)
out_table <- network2table(out)
rk_table[rr, 3] <- which(out_table$Gene1 == gene_to & out_table$Gene2 == gene_from)


}

return(rk_table)
}



