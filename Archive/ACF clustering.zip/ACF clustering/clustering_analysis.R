## Decided to only use "ACF" clustering method
# March 19th

# clustering script

dat_norm <- read.table('normalized_counts_gene-names.csv',
                       header=TRUE, row.names=1, as.is=TRUE, 
                       check.names=FALSE, sep=',')
dat_short <- subset(dat_norm, select = -c(4,19,20,21,39,40,41))

subset_551 <- as.character(read.csv("union_DE.214_limmavoom.411_551.csv")$x)
dat = dat_short[rownames(dat_short) %in% subset_551,]


core_91 <- as.character(read.csv('DE_91_core.csv',header=F)$V2)
top_214 <- as.character(read.csv('DE_214.csv',header=F)$V2)


#install.packages("TSclust")
#install.packages("ape")

library(TSclust)
library(ape)
library(reshape2)
library(gdata)
library(network)
source("functions.r")
load("Gene_Master_Summary.RData")

X_a = t(dat[,1:17])  # only using replicate A
X_b = t(dat[,18:34]) # only using replicate B

###### =====================CLUSTERING ===============================
# 1) =========== ACF ====================
tsdist_A <- diss(t(X_a), "ACF", p=0.05) # takes some time
tsdist_B <- diss(t(X_b), "ACF", p=0.05) # takes some time

save(tsdist_A,tsdist_B,file="tsdist_both_ACF_551.Rdata")

tsmat_A <- as.matrix(tsdist_A)
# p <- nrow(tsmat_A)
# genes.row <- array(rep(rownames(tsmat_A), p), c(p,p))
# genes.col <- t(genes.row)
# tstable_A <- data.frame('gene1' = upperTriangle(genes.row, diag=FALSE)
#                     , 'gene2' = upperTriangle(genes.col, diag=FALSE)
#                     , 'dist_A' = upperTriangle(tsmat_A, diag=FALSE)
#                     , stringsAsFactors = FALSE)
# tstable_A_filtered <- tstable_A[tstable_A$dist_A < 1,]
#write.csv(tstable_A_filtered,file="tstable_A_filtered.csv")

tsmat_B <- as.matrix(tsdist_B)
# p <- nrow(tsmat_B)
# genes.row <- array(rep(rownames(tsmat_B), p), c(p,p))
# genes.col <- t(genes.row)
# tstable_B <- data.frame('gene1' = upperTriangle(genes.row, diag=FALSE)
#                       , 'gene2' = upperTriangle(genes.col, diag=FALSE)
#                       , 'dist_B' = upperTriangle(tsmat_B, diag=FALSE)
#                       , stringsAsFactors = FALSE)

save(tsmat_A,tsmat_B,file="tsmat_both_ACF_551.Rdata")

#tstable_joint <- merge(tstable_A,tstable_B,by=c('gene1','gene2'))
#save(tstable_joint,file="tstable_joint_ACF.Rdata")
#write.csv(tstable_joint,file="tstable_joint_ACF.csv")

load("tsmat_both_ACF_551.Rdata")
# choose how to filter
hist(tsmat_A)
hist(tsmat_B)
# 0 means more similar
# 0.5 and above means less similar

# filter to genes that cluster to core 91
# push genes that do not cluster with core_91 to 1

tsmat_A[!(rownames(tsmat_A) %in% core_91), !(colnames(tsmat_A) %in% core_91)] <- 1
tsmat_B[!(rownames(tsmat_B) %in% core_91), !(colnames(tsmat_B) %in% core_91)] <- 1

hist(tsmat_A)
hist(tsmat_B)

save(tsmat_A,tsmat_B,file="tsmat_both_filtered_ACF_551.Rdata")

### START FILTERING HERE
load("tsmat_both_filtered_ACF_551.Rdata")
# Try getting pretty network plots
A = tsmat_A
hist(A)
hist(A[A < 1]) # try to get normal distribution

quantile(as.vector(A[A < 1]), prob = seq(0,10)/100)
# top 1% by cutoff 0.05
A[A > 0.05] = 1 # cutoff here <---------------- (for tail closest to 0)
A = 1-A # distance to similarity matrix
diag(A) = 0
# drop_genes = apply(A, 1, FUN = function(v){return(all(v==0))})
# sum(drop_genes == 1)
# A = A[!drop_genes, !drop_genes]
pdf('network_cluster_ACF_A_551_test.pdf', height = 30, width = 30)
plot(network(A), label=rownames(A),
   usearrows = FALSE, displayisolates = FALSE, vertex.cex = 0.5
   # , thresh = 0.65
   )
dev.off()


## to cut the "tree"

AA = A; AA[A < 0.5]=0
AA[AA>0.5]=1
id = rowSums(AA)!=0
sum(id)
AB <- AA[id, id]
table(AB)
AB = (!AB)+0.0
table(AB)
diag(AB)=0

### cut network into sub clusters
out <- cutree(hclust(as.dist(AB), method='single'), h=0.5); table(out)



#### test

tsmat_A <- as.matrix(tsdist_A)
A = tsmat_A
A[!(rownames(A) %in% core_91), !(colnames(A) %in% core_91)] <- 1
A[A > 0.05] = 1 # cutoff here <---------------- (for tail closest to 0)
A = 1-A # distance to similarity matrix
diag(A) = 0



list_of_interest <- list_of_subsets[[8]]
plot_subset("name",list_of_interest,1,18)

plot_subset("name",c("aralar1","LRP1",
                     "to","Gp93",
                     "Invadolysin"),1,18)

list_of_interest <- c("aralar1","LRP1",
  "to","Gp93",
  "Invadolysin")

new_table <- my_data[my_data$GeneSymbol %in% list_of_interest,]

new_table[,2:7]



#### test

load("tsdist_both_ACF_551.Rdata")

tsmat_A <- as.matrix(tsdist_A)
A = tsmat_A
#A[!(rownames(A) %in% core_91), !(colnames(A) %in% core_91)] <- 1
#A[!(rownames(A) %in% top_214), !(colnames(A) %in% top_214)] <- 1
#quantile(as.vector(A[A < 1]), prob = seq(0,10)/100)
cutoff = 0.059
A[A > cutoff] = 1; A = 1-A ; diag(A) = 0
AA = A; AA[A < 0.5]=0; AA[AA>0.5]=1; id = rowSums(AA)!=0; AB <- AA[id, id]; AB = (!AB)+0.0; diag(AB)=0

out <- cutree(hclust(as.dist(AB), method='single'), h=0.5); table(out)


out[out ==as.numeric(out["AttC"])]
# DptA Dro AttA Mtk DptB PGRP-SD AttC AttB PGRP-SB1 edin CG43236 CG43920 CR44404 CR45045 (0.07)
# DptA Dro AttA Mtk DptB PGRP-SD AttC AttB PGRP-SB1 edin CG43236 CG43920 CR44404 CR45045 (0.06)
# DptA Dro AttA Mtk DptB PGRP-SD AttC AttB edin CG43236 CG43920 CR44404 CR45045 (0.055)
# DptA AttA DptB PGRP-SD AttC AttB edin CG43236 CG43920 CR44404 CR45045 (0.05)
# DptA DptB AttC CG43236 CR44404 CR45045 (0.047)
# DptA DptB AttC CR45045 (0.045)

out[out ==as.numeric(out["TotA"])]
# TotA TotM CG11459 TotB Grik Diedel lectin-24A CG16836 TotX TotC CG30287 NimB3 (0.035)

out[out ==as.numeric(out["Hsp70Aa"])]
# Hsp70Aa  Hsp70Ab  Hsp70Ba  Hsp70Bb  Hsp70Bc  CG16749  CG31300 Hsp70Bbb (0.055)
# Hsp70Aa  Hsp70Ab  Hsp70Ba  Hsp70Bb  Hsp70Bc  CG31300 Hsp70Bbb (0.05)
# Hsp70Aa Hsp70Ab (0.04)

out[out ==as.numeric(out["IM23"])]
# IM23 IM1 IM4 CG33470 IM14 IMPPP (0.05)

out[out ==as.numeric(out["AttC"])]
list_of_interest <- names(out[out ==as.numeric(out["AttC"])])
plot_subset("name",list_of_interest,1,18)

out[out ==as.numeric(out["IM23"])]
list_of_interest <- names(out[out ==as.numeric(out["Orc1"])])
plot_subset("name",list_of_interest,1,18)

out_M <- as.matrix(out)

#name = "Figure_network_clustertest4.pdf"
#pdf(name,width=30,height=30,paper="special")
plot(network(A), label=rownames(A),
     usearrows = FALSE, displayisolates = FALSE, vertex.cex = 0.5
     # , thresh = 0.65
)
#dev.off()

### cluster 3
tsmat_A <- as.matrix(tsdist_A)
tsmat_A[!(rownames(tsmat_A) %in% cluster3), 
        !(colnames(tsmat_A) %in% cluster3)] <- 1
A = tsmat_A
quantile(as.vector(A[A < 1]), prob = seq(0,10)/100)

cutoff = as.numeric(quantile(as.vector(A[A < 1]), prob = 0.01))
#cutoff = 0.035
A[A > cutoff] = 1 # cutoff here <---------------- (for tail closest to 0)
A = 1-A # distance to similarity matrix
diag(A) = 0
AA = A; AA[A < 0.5]=0
AA[AA>0.5]=1
id = rowSums(AA)!=0
sum(id)
AB <- AA[id, id]
table(AB)
AB = (!AB)+0.0
table(AB)
diag(AB)=0

### cut network into sub clusters
out <- cutree(hclust(as.dist(AB), method='single'), h=0.5); table(out)

out[out ==as.numeric(out["IM14"])]
list_of_interest <- names(out[out ==as.numeric(out["IM14"])])
plot_subset("name",list_of_interest,1,18)

out[out ==as.numeric(out["edin"])]
list_of_interest <- names(out[out ==as.numeric(out["TotX"])])
plot_subset("name",list_of_interest,1,18)

#name = "Figure_network_cluster3.pdf"
#pdf(name,width=30,height=30,paper="special")
plot(network(A), label=rownames(A),
     usearrows = FALSE, displayisolates = FALSE, vertex.cex = 0.5
     # , thresh = 0.65
)
#dev.off()



###
### cluster 1
tsmat_A <- as.matrix(tsdist_A)
tsmat_A[!(rownames(tsmat_A) %in% cluster4), 
        !(colnames(tsmat_A) %in% cluster4)] <- 1
A = tsmat_A
quantile(as.vector(A[A < 1]), prob = seq(0,10)/100)

#cutoff = as.numeric(quantile(as.vector(A[A < 1]), prob = 0.01))
cutoff = 0.04
A[A > cutoff] = 1 # cutoff here <---------------- (for tail closest to 0)
A = 1-A # distance to similarity matrix
diag(A) = 0
AA = A; AA[A < 0.5]=0
AA[AA>0.5]=1
id = rowSums(AA)!=0
sum(id)
AB <- AA[id, id]
table(AB)
AB = (!AB)+0.0
table(AB)
diag(AB)=0

### cut network into sub clusters
out <- cutree(hclust(as.dist(AB), method='single'), h=0.5); table(out)
table(out)
out[out ==3]
list_of_interest <- names(out[out == 8])
plot_subset("name",list_of_interest,1,18)

out[out ==as.numeric(out["TotX"])]
list_of_interest <- names(out[out ==as.numeric(out["TotX"])])
plot_subset("name",list_of_interest,1,18)

out_M <- as.matrix(out)





########## 
## Baby coding:

# for(i in 1:length(colnames(tsmat_A))){ # columns
#   for(j in 1:length(rownames(tsmat_A))){ # rows
#     if(!(rownames(tsmat_A)[i] %in% core_91) & 
#        !(colnames(tsmat_A)[j] %in% core_91) == TRUE){
#       tsmat_A[i,][j] <- 1}}}
# 
# for(i in 1:length(colnames(tsmat_B))){ # columns
#   for(j in 1:length(rownames(tsmat_B))){ # rows
#     if(!(rownames(tsmat_B)[i] %in% core_91) & 
#        !(colnames(tsmat_B)[j] %in% core_91) == TRUE){
#       tsmat_B[i,][j] <- 1}}}



# A is the original matrix

# A1 <- A[!rowSums(A)==0,] # remove genes with all zeros in a row
# A2 <- A1[,!colSums(A1)==0] # remove genes with all zeros in a column
# 
# A2 <- as.data.frame(A2) # turn matrix into data frame because R is weird otherwise
# 
# genes_to_run <- rownames(A2) # initiate list of genes yet to check
# already_ran_gene <- c() # initiate empty list of genes already checked
# list_of_subsets <- list() # initiate empty list of lists to append the results
# while(length(genes_to_run) > 0){ # while there are any genes yet to check
#   new_set <- c() # initiate one single set
#   gene <- genes_to_run[1] # take the first gene from list of genes yet to check (gene A)
#   while (!is.na(gene)) { # if gene A exists...
#     if (!gene %in% already_ran_gene) { # if gene A has not been run yet...
#       new_genes <- c(new_set, rownames(A2[A2[gene, ] != 0, ])) # append all genes interacting with gene A
#       for (i in 1:length(new_genes)) { # for each new gene that interacts with original gene A (interactors list)...
#         if (!new_genes[i] %in% new_set) { # if this gene (gene B) is not in the set already...
#           new_set <- c(new_set, new_genes[i]) # append gene B to the set
#         }
#       }
#       already_ran_gene <- c(already_ran_gene, gene) # append gene A into the list of already ran genes
#     }
#     new_set_filtered <- new_set[!new_set %in% already_ran_gene] # remove gene B from the interactors list
#     gene = new_set_filtered[1] # choose a new gene to check from the list of interactors
#   }
#   print(new_set)
#   genes_to_run <- genes_to_run[!genes_to_run %in% already_ran_gene] # update list of genes yet to check by removing all those already ran
#   list_of_subsets <- append(list_of_subsets,list(new_set)) # append final set to list of lists with results
# }


lapply(list_of_subsets, 
       function(x) write.table( data.frame(x), 'subset.csv'  , append= T, sep=',' ))

ddd <- data.frame(subset=1:length(list_of_subsets),genes=I(unlist(lapply(list_of_subsets,paste,collapse=","))))
write.csv(ddd,file="test_subsets.csv",quote=FALSE,row.names=FALSE)


A <- as.matrix(tsdist_A)
hist(A)
out <- cutree(hclust(as.dist(A)), h=0.2); table(out)

