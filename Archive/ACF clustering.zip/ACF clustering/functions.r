require(limma)
require(edgeR)
require(splines)
require(DESeq2)
require(gdata)
require(reshape2)
require(ggplot2)
source('library.r')


generate_initial_data <- function(dat.A # a pxT matrix of normalized counts from replicate A [dim(dat.A) = dim(dat.B)]
                     , dat.B # a pxT matrix of normalized counts from replicate B [dim(dat.A) = dim(dat.B)]
					 , timepts = 1:4 # set of time points to use in GC analysis -- a numeric vector 
					 , genesets # a character vector with the names of genes to be analyzed
					  ){
if (any(dim(dat.A)!=dim(dat.B))){stop('Error: dat.A and dat.B have different dimensions')}
if (any(rownames(dat.A)!=rownames(dat.B))){stop('Error: genes are not in same order!!!')}

dat.A = dat.A[rownames(dat.A) %in% genesets,]
dat.B = dat.B[rownames(dat.B) %in% genesets,]

tt = length(timepts)
p = nrow(dat.A)
gene_label = rownames(dat.A)

XX = t(cbind(dat.A[,timepts[1:(tt-1)]], dat.B[,timepts[1:(tt-1)]]))
YY = t(cbind(dat.A[,timepts[2:tt]], dat.B[,timepts[2:tt]]))

return(list(X=XX, Y=YY))
}


# takes as input two pxT matrices dat.A and dat.B of same size
# containing normalized log-counts from replicates A and B, and gene names (in same order) on their rows
# and a subset of genes;
# Forms network of significant GC relationships between each pair of genes;
# outputs a list of two pxp matrices with GC estimates and pvalues
# optionally, writes top XX significant edges in a tab-separated .txt file
GCnet_pwvar <- function(dat.A # a pxT matrix of normalized counts from replicate A [dim(dat.A) = dim(dat.B)]
                     , dat.B # a pxT matrix of normalized counts from replicate B [dim(dat.A) = dim(dat.B)]
					 , timepts = 1:4 # set of time points to use in GC analysis -- a numeric vector 
					 , genesets # a character vector with the names of genes to be analyzed
					 , out_fname = NULL
					 , keep_top_edges = 500
					  ){
if (any(dim(dat.A)!=dim(dat.B))){stop('Error: dat.A and dat.B have different dimensions')}
if (any(rownames(dat.A)!=rownames(dat.B))){stop('Error: genes are not in same order!!!')}

dat.A = dat.A[rownames(dat.A) %in% genesets,]
dat.B = dat.B[rownames(dat.B) %in% genesets,]

tt = length(timepts)
p = nrow(dat.A)
gene_label = rownames(dat.A)

XX = t(cbind(dat.A[,timepts[1:(tt-1)]], dat.B[,timepts[1:(tt-1)]]))
YY = t(cbind(dat.A[,timepts[2:tt]], dat.B[,timepts[2:tt]]))

ff = net_pwvar_parr(X = NULL
                  , XX = XX 
                  , YY = YY 
				   )
rownames(ff$adj) <- gene_label; rownames(ff$pval) <- gene_label
colnames(ff$adj) <- gene_label; colnames(ff$pval) <- gene_label

# write networks in a table
rowlabs = matrix(gene_label, nrow=p, ncol=p)
collabs = t(rowlabs)

out = data.frame(Gene1 = c(upperTriangle(rowlabs, diag=FALSE, byrow=TRUE)
                         , lowerTriangle(rowlabs, diag=FALSE, byrow=FALSE))
         , Gene2 = c(upperTriangle(collabs, diag=FALSE, byrow=TRUE)
		           , lowerTriangle(collabs, diag=FALSE, byrow=FALSE))
		 , edgewt = c(upperTriangle(ff$adj, diag=FALSE, byrow=TRUE)
		           , lowerTriangle(ff$adj, diag=FALSE, byrow=FALSE))
		 , pval = c(upperTriangle(ff$pval, diag=FALSE, byrow=TRUE)
		           , lowerTriangle(ff$pval, diag=FALSE, byrow=FALSE))
		 , stringsAsFactors=FALSE
		   )
		   
out$adjpval.BH = p.adjust(out$pval, method='BH')
out$adjpval.BY = p.adjust(out$pval, method='BY')
out$adjpval.bonferroni = p.adjust(out$pval, method='bonferroni')

out = out[order(out$pval),]

if (!is.null(out_fname)){
  out = out[1:keep_top_edges,]
  write.table(out, sep='\t', file = out_fname, row.names = FALSE) 
}

return(ff)
}



GCnet_l1var <- function(dat.A # a pxT matrix of normalized counts from replicate A [dim(dat.A) = dim(dat.B)]
                        , dat.B # a pxT matrix of normalized counts from replicate B [dim(dat.A) = dim(dat.B)]
                        , timepts = 1:4 # set of time points to use in GC analysis -- a numeric vector 
                        , genesets # a character vector with the names of genes to be analyzed
                        , out_fname = NULL
                        , keep_top_edges = 500
                        , use.package.hdi = FALSE
){
  if (any(dim(dat.A)!=dim(dat.B))){stop('Error: dat.A and dat.B have different dimensions')}
  if (any(rownames(dat.A)!=rownames(dat.B))){stop('Error: genes are not in same order!!!')}
  
  dat.A = dat.A[rownames(dat.A) %in% genesets,]
  dat.B = dat.B[rownames(dat.B) %in% genesets,]
  
  tt = length(timepts)
  p = nrow(dat.A)
  gene_label = rownames(dat.A)
  
  XX = t(cbind(dat.A[,timepts[1:(tt-1)]], dat.B[,timepts[1:(tt-1)]]))
  YY = t(cbind(dat.A[,timepts[2:tt]], dat.B[,timepts[2:tt]]))
  
  # print(dim(XX))
  # print(dim(YY))
  
  if (use.package.hdi == FALSE){
  ff = net_l1var_parr(X = NULL
                      , XX = XX 
                      , YY = YY 
  )
  }
  
  if (use.package.hdi == TRUE){
    # print(dim(XX))
    # print(dim(YY))
    
    # for (j in 1:p){
    #   print(j)
    #   ff = lasso.proj(x=XX, y=as.vector(YY[,j]), parallel = FALSE, standardize = FALSE, multiplecorr.method = 'none')
    # print(ff$pval)
    # }
    
    ff = net_l1var_parr_hdi(X = NULL
                        , XX = XX
                        , YY = YY
    )
  }
  
  rownames(ff$adj) <- gene_label; rownames(ff$pval) <- gene_label; 
  rownames(ff$test_statistic) <- gene_label
  colnames(ff$adj) <- gene_label; colnames(ff$pval) <- gene_label
  colnames(ff$test_statistic) <- gene_label
  
  # write networks in a table
  rowlabs = matrix(gene_label, nrow=p, ncol=p)
  collabs = t(rowlabs)
  
  
  
  out = data.frame(Gene1 = c(upperTriangle(rowlabs, diag=FALSE, byrow=TRUE)
                             , lowerTriangle(rowlabs, diag=FALSE, byrow=FALSE))
                   , Gene2 = c(upperTriangle(collabs, diag=FALSE, byrow=TRUE)
                               , lowerTriangle(collabs, diag=FALSE, byrow=FALSE))
                   , edgewt = c(upperTriangle(ff$adj, diag=FALSE, byrow=TRUE)
                                , lowerTriangle(ff$adj, diag=FALSE, byrow=FALSE))
                   , pval = c(upperTriangle(ff$pval, diag=FALSE, byrow=TRUE)
                              , lowerTriangle(ff$pval, diag=FALSE, byrow=FALSE))
                   , test_statistic = c(upperTriangle(ff$test_statistic, diag=FALSE, byrow=TRUE)
                              , lowerTriangle(ff$test_statistic, diag=FALSE, byrow=FALSE))
                   , stringsAsFactors=FALSE
  )
  
  out$adjpval.BH = p.adjust(out$pval, method='BH')
  out$adjpval.BY = p.adjust(out$pval, method='BY')
  out$adjpval.bonferroni = p.adjust(out$pval, method='bonferroni')
  
  out = out[order(out$pval, -out$test_statistic),]
  
  if (!is.null(out_fname)){
    out = out[1:keep_top_edges,]
    write.table(out, sep='\t', file = out_fname) 
  }
  
  return(ff)
}

network2table <- function(out_GCnet){

  ff = out_GCnet
  gene_label = rownames(ff$pval)
  p = nrow(ff$pval)
  
  # write networks in a table
  rowlabs = matrix(gene_label, nrow=p, ncol=p)
  
  collabs = t(rowlabs)
  
  out = data.frame(Gene1 = c(upperTriangle(rowlabs, diag=FALSE, byrow=TRUE)
                             , lowerTriangle(rowlabs, diag=FALSE, byrow=FALSE))
                   , Gene2 = c(upperTriangle(collabs, diag=FALSE, byrow=TRUE)
                               , lowerTriangle(collabs, diag=FALSE, byrow=FALSE))
                   , edgewt = c(upperTriangle(ff$adj, diag=FALSE, byrow=TRUE)
                                , lowerTriangle(ff$adj, diag=FALSE, byrow=FALSE))
                   , pval = c(upperTriangle(ff$pval, diag=FALSE, byrow=TRUE)
                              , lowerTriangle(ff$pval, diag=FALSE, byrow=FALSE))
                   , test_statistic = c(upperTriangle(ff$test_statistic, diag=FALSE, byrow=TRUE)
                              , lowerTriangle(ff$test_statistic, diag=FALSE, byrow=FALSE))
                   , stringsAsFactors=FALSE
  )
  

  
  out$adjpval.BH = p.adjust(out$pval, method='BH')
  out$adjpval.BY = p.adjust(out$pval, method='BY')
  out$adjpval.bonferroni = p.adjust(out$pval, method='bonferroni')
  
  out = out[order(out$pval, -out$test_statistic),]
  
return(out)
}






plot_GCnet <- function(output_GCnet
                   , p.adjust.method = 'none' # choose from 'none', 'BH', 'bonferroni'
				   , pval.cut = 0.05 # only show edges with adjusted pvalue less than this cutoff
                   , ... # additional output to net_plot 
					){
ff = output_GCnet
gene_label = rownames(ff$adj)					
grf = fit2graph(ff$adj, ff$pval, method=p.adjust.method, thresh.cutoff = pval.cut, convert2undirected = FALSE, combine.directed.edges = 'or')
rownames(grf) <- gene_label; colnames(grf) <- gene_label

# only keep imp genes
drop.row = which(rowSums(grf)==0)
drop.col = which(colSums(grf)==0)
drop.genes = intersect(drop.row, drop.col)
grf = grf[-drop.genes, -drop.genes]

net_plot(t(grf), node_label = rownames(grf), usearrows = TRUE, arrowhead.cex = 0.5, ...)
}

##### example call ######
if (FALSE){
dat = read.csv('new_normalized_counts.csv', header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)
genelist.bioproc = read.csv('all_genes_biological-processp.value_0.1_score_1_2tp.csv'
                          , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
genelist.cellcomp = read.csv('all_genes_cellular-compartmentp.value_0.1_score_0.5_2tp.csv'
                          , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
genelist.molfunc = read.csv('all_genes_molecular-function_p.value_0.1_score_0.6_2tp.csv'
                          , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
dat = data.matrix(dat)
dat = dat[,-4]

dat.A = dat[,1:20]
dat.B = dat[,21:40]

out <- GCnet_pwvar(dat.A = dat.A, dat.B = dat.B, genesets = genelist.bioproc[1:20], keep_top_edges = 100, out_fname = 'GC_bioproc.txt')

pdf('GCnet_bioproc.pdf'
  , height = 15, width = 15)
plot_GCnet(out, pval.cut = 0.007, p.adjust.method='none')
dev.off()

}

# ANOTHER example call -- lasso
if (FALSE){
  dat = read.csv('new_normalized_counts.csv', header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)
  genelist.bioproc = read.csv('all_genes_biological-processp.value_0.1_score_1_2tp.csv'
                              , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
  genelist.cellcomp = read.csv('all_genes_cellular-compartmentp.value_0.1_score_0.5_2tp.csv'
                               , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
  genelist.molfunc = read.csv('all_genes_molecular-function_p.value_0.1_score_0.6_2tp.csv'
                              , header=TRUE, row.names=1, as.is=TRUE, check.names=FALSE)$x
  dat = data.matrix(dat)
  dat = dat[,-4]
  
  dat.A = dat[,1:20]
  dat.B = dat[,21:40]
  
  out <- GCnet_l1var(dat.A = dat.A, dat.B = dat.B
                     , genesets = genelist.bioproc
                     , keep_top_edges = 10000, out_fname = 'GC_bioproc_lasso.txt')
  
  pdf('GCnet_bioproc_lasso.pdf'
      , height = 15, width = 15)
  plot_GCnet(out, pval.cut = 0.0001, p.adjust.method='none')
  dev.off()
  
}


LRT_limmavoom <- function(
  dat            # A matrix of (normalized) counts, dimension: no. genes x no. timepts
, time_ID        # a numeric vector of time pts
, gene_name     # a character vector of gene names
, design_type  # type of curve and degree of freedom as a vector
                               # choices: c('spline', *) or c('polynomial', *) 
, normalize_method = 'TMM'     # set it TMM for now, will add other variations later
, pval_cutoff = 0.05            
){
  no_gene = nrow(dat); no_timept = ncol(dat)
  if (length(gene_name)!=no_gene){stop("length of gene names do not match data size")}
  if (length(time_ID)!=no_timept){stop("length of timepts does not match data size")}
  
  rownames(dat) = gene_name; colnames(dat) = time_ID
  
  # construct design matrix
  if (design_type[1]=='spline'){
    df = as.numeric(design_type[2])
    design = model.matrix(~ns(time_ID, df))
  }
  if (design_type[1]=='polynomial'){
    df = as.numeric(design_type[2])
    design = model.matrix(~poly(time_ID, df))
  }
  
  # apply normalization
  if (normalize_method == "TMM"){
    dat = DGEList(counts = dat)
    dat = calcNormFactors(dat)
  }
  
  # use voom transform for precision weights
  voomdat = voom(dat, design=design, normalize.method='none', plot=T)
  
  # fit linear models to univariate time course trajectories
  fit = lmFit(voomdat, design = design, weights=NULL)
  dat_smoothed = fit$coefficients %*% t(fit$design)
  fit = eBayes(fit, trend=TRUE)
  top = topTable(fit, coef=seq(2, (df+1)), sort.by="B", number=nrow(dat), p.value=pval_cutoff)
  
  return(list(top=top, dat_smoothed = dat_smoothed))
}


DE_timecourse = function(
  dat1, dat2                   # Two matrices of (normalized) counts, each with dimension: no. genes x no. timepts, make sure the gene names are ordered alphabetically (note to sumanta: see if you can change within the function)
, time_ID                      # a numeric vector of time points
, gene_name                    # a character vector of gene names
, design_type # type of curve and degree of freedom as a vector
                               # choices: c('spline', *) or c('polynomial', *) 
, normalize_method = 'TMM'     # set it TMM for now, will add other variations later
, save_output = FALSE
, out_fname = 'DE_timecourse.RData'
){
  no_gene = nrow(dat1); no_timept = ncol(dat1); T = no_timept-1; p = no_gene
  if (length(gene_name)!=no_gene){stop("length of gene names do not match data size")}
  if (length(time_ID)!=no_timept){stop("length of timepts does not match data size")}
  if (any(dim(dat1)!=dim(dat2))){stop("two replicate datasets have different size")}
  
  # construct design matrix
  if (design_type[1]=='spline'){
    df = as.numeric(design_type[2])
    design = model.matrix(~ns(time_ID, df))
  }
  if (design_type[1]=='polynomial'){
    df = as.numeric(design_type[2])
    design = model.matrix(~poly(time_ID, df))
  }
  
  # apply normalization
  if (normalize_method == "TMM"){
    dat1 = DGEList(counts = dat1); dat1 = calcNormFactors(dat1)
    dat2 = DGEList(counts = dat2); dat2 = calcNormFactors(dat2)
  }
  
  # use voom transform for precision weights
  voomdat1 = voom(dat1, design=design, normalize.method='none', plot=T)
  voomdat2 = voom(dat2, design=design, normalize.method='none', plot=T)
  dat1.voom = voomdat1$E; dat2.voom = voomdat2$E
  
  
  # combine replicates in a single dataset
  dat = cbind(dat1.voom, dat2.voom)
  rownames(dat) = gene_name; colnames(dat) = rep(time_ID, 2)

  # fit linear model to aggregate two replicates at each time point
  des_contrast = rbind(diag(T+1), diag(T+1))
  fit = lmFit(dat, des_contrast)
  
  # construct contrast matrix for DE testing (time t - time 0)
  cont = rbind(matrix(rep(-1, T), nrow=1, ncol=T)
               , diag(T))
  ffc = contrasts.fit(fit, cont)
  ffceb = eBayes(ffc)
  
  result = list()
  pval = array(1, c(p, T))
  rownames(pval) = gene_name
  colnames(pval) = paste("t",time_ID[-1], ":t0", sep="")
  logFC = array(0, c(p, T))
  rownames(logFC) = gene_name
  colnames(logFC) = paste("t", time_ID[-1], ":t0", sep="")
  
  
  for (j in 1:T){
    tmp = topTable(ffceb, coef = j, number = p, adjust = "none")
    tmp$gene = rownames(tmp)
    tmp = tmp[order(tmp$gene),]
	print(head(tmp))
	print(head(pval))
	
    if (any(rownames(tmp)!=rownames(pval)))
      print(paste('orders of genes do not match for coef ', j))
    result[[j]] = tmp
    pval[,j] <- tmp$adj.P.Val
    logFC[,j] <- tmp$logFC
  }
  
  if (save_output)
  save(pval, logFC, result, file = out_fname)
  
return(list(pvalue = pval, logFoldChange = logFC))  
  
}

filter_genes <- function(
  pvalue                   # a matrix of size #genes x (#timepts-1), as in the output of DE_timecourse
, logFC            # a matrix of size #genes x (#timepts-1), as in the output of DE_timecourse
, p_adjust_method = 'none' # options: 'bonferroni', 'BH', 'BY', see p.adjust() for all available options
, p_cut
, logFC_cut
, rule = 'and'             # options: 'and', 'or'
, t_cut = 1            # only keep genes which are differential in atleast t_cut timepts
){

if (any(dim(pvalue)!=dim(logFC))){stop("dimensions of pval and logFC do not match!!")}
out <- logFC

# correct for multiple testing
if (p_adjust_method!='none'){
tmp = matrix(p.adjust(as.vector(pvalue), method=p_adjust_method)
              , nrow(pvalue), ncol(pvalue)
			   )
rownames(tmp) = rownames(pvalue)
colnames(tmp) = colnames(pvalue)
pvalue <- tmp
rm(tmp)			   
}

# set all logFC with high pval and/or low logFC to zero 
if (rule == 'and')
  out[!((pvalue <= p_cut) & (abs(logFC) >= logFC_cut))] = 0
else
  out[!((pvalue <= p_cut) | (abs(logFC) >= logFC_cut))] = 0

# keep only genes differentially expressed in atleast t_cut  points
keep_genes_idx = (rowSums(!!out) >= t_cut)

return(list(adj.pvalue = pvalue[keep_genes_idx,], logFoldChange = out[keep_genes_idx,]))
}



# plot time course genes
plot_norm.counts <- function(gene.type,list_of_interest){
  translation_table <- as.data.frame(read.table("../Data/FlyBase_IDs_conversion-table.txt",
                                                header=TRUE))

  dat_table = read.table('../Data/normalized_counts.csv',
                         header=TRUE, row.names=1, 
                         as.is=TRUE, check.names=FALSE, sep=',')
  dat_table = subset(dat_table, select = -c(19,20,21,39,40,41))
  sample_table <- read.csv("../Data/samples_table_no_4B.csv",header=TRUE)
  sample_table <- sample_table[-c(19,20,21,39,40,41),]

  genes_from_time_course <- dat_table
  start_table <- sample_table 
  
  datalist = list()
  
  for(word in list_of_interest){
    if(gene.type == 'ID'){
      gene_ID = word
      gene_name = as.character(translation_table[translation_table$'submitted_id' == word, ][[4]])
    }
    if(gene.type == 'name'){
      gene_ID = as.character(translation_table[translation_table$'current_symbol' == word, ][[1]])
      gene_name = word
    }
    if(gene_ID %in% rownames(genes_from_time_course)){
      gene_counts <- melt(genes_from_time_course[gene_ID,])$"value"
      start_table["counts"] <- gene_counts
      start_table["gene"] <- c(rep(gene_name,length(gene_counts)))
      start_table["gene_ID"] <- c(rep(gene_ID,length(gene_counts)))
      datalist[[gene_ID]] <- start_table
    }
  }
  
  big_data = do.call(rbind,datalist)
  big_data['group'] <- paste(big_data$gene,big_data$replicate,sep="_")
  
  ggplot(big_data, aes(x=hours, y=counts, color=gene, group=group)) +
    geom_point(size=3) + 
    geom_line() + 
    theme(axis.text=element_text(size=15),
          legend.text=element_text(size=15),
          legend.title=element_text(size=15),
          axis.title.x=element_text(size=18, margin=margin(15,0,0,0)),
          axis.title.y=element_text(size=18, margin=margin(0,5,0,0))) +
    scale_x_continuous(breaks=c(0,12,24,36,48,72,96,120)) +
    scale_y_continuous(breaks=c(5,7,9,11,13)) +
    ylab("normalized counts") +
    xlab("hours since injection") +
    labs(title = paste(list_of_interest,collapse=", "))

}

plot_log.fold <- function(gene.type,list_of_interest){
  translation_table <- as.data.frame(read.table("../Data/FlyBase_IDs_conversion-table.txt",
                                                header=TRUE))
  
  dat_table = read.table('Results/log_fold_change_short_ALL-DE.csv',
                         header=TRUE, row.names=1, 
                         as.is=TRUE, check.names=FALSE, sep=',')
  colnames(dat_table) <-  c("2","3","5","6","7","8","9","10",
                            "11","12","13","14","15","16","17","18")
  dat_table$"1" <- c(rep(0,length(rownames(dat_table))))
  dat_table <- dat_table[c("1","2","3","5","6","7","8","9","10",
                           "11","12","13","14","15","16","17","18")]
  sample_table <- read.table("../Data/sample_table_logFC.txt",header=TRUE)
  sample_table <- sample_table[-c(18,19,20),]
  
  genes_from_time_course <- dat_table
  start_table <- sample_table 
  
  datalist = list()
  
  for(word in list_of_interest){
    if(gene.type == 'ID'){
      gene_ID = word
      gene_name = as.character(translation_table[translation_table$'submitted_id' == word, ][[4]])
    }
    if(gene.type == 'name'){
      gene_ID = as.character(translation_table[translation_table$'current_symbol' == word, ][[1]])
      gene_name = word
    }
    if(gene_ID %in% rownames(genes_from_time_course)){
      gene_counts <- melt(genes_from_time_course[gene_ID,])$"value"
      start_table["counts"] <- gene_counts
      start_table["gene"] <- c(rep(gene_name,length(gene_counts)))
      start_table["gene_ID"] <- c(rep(gene_ID,length(gene_counts)))
      datalist[[gene_ID]] <- start_table
    }
  }
  
  big_data = do.call(rbind,datalist)
  big_data['group'] <- paste(big_data$gene,big_data$replicate,sep="_")
  
  ggplot(big_data, aes(x=hours, y=counts, color=gene)) +
    geom_point(size=3) + 
    geom_line() + 
    theme(axis.text=element_text(size=15),
          legend.text=element_text(size=15),
          legend.title=element_text(size=15),
          axis.title.x=element_text(size=18, margin=margin(15,0,0,0)),
          axis.title.y=element_text(size=18, margin=margin(0,5,0,0))) +
    scale_x_continuous(breaks=c(0,12,24,36,48,72,96,120)) +
    ylab("log fold change") +
    xlab("hours since injection") +
    labs(title = paste(list_of_interest,collapse=", "))
}
### example of how to use:
# plot_log.fold("name",c("APC7","PGRP-LC"))





# Multiple plot function
#
# ggplot objects can be passed in ..., or to plotlist (as a list of ggplot objects)
# - cols:   Number of columns in layout
# - layout: A matrix specifying the layout. If present, 'cols' is ignored.
#
# If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
# then plot 1 will go in the upper left, 2 will go in the upper right, and
# 3 will go all the way across the bottom.
#
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
  
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}


### START HERE

plot_subset <- function(gene.type,list_of_interest,start,end){
  translation_table <- as.data.frame(read.table("../Data/FlyBase_IDs_conversion-table.txt",
                                                header=TRUE))
  
  ### PLOT 1: normalized counts WITH SUBSET
  norm.counts_table = read.table('../Data/normalized_counts.csv',
                                 header=TRUE, row.names=1, 
                                 as.is=TRUE, check.names=FALSE, sep=',')
  norm.counts_table = subset(norm.counts_table, select = -c(4,19,20,21,39,40,41))
  norm.counts_sample.table <- read.csv("../Data/samples_table_no_4B.csv",header=TRUE)
  norm.counts_sample.table <- norm.counts_sample.table[-c(4,19,20,21,39,40,41),]
  
  start.names = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == start,]$sample_ID)
  end.names = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == end,]$sample_ID)
  if(start == 4){start.names[2] = '5B'}
  if(end == 4){end.names[2] = '3B'}
  desired_col_ranges = c(match(start.names[1],colnames(norm.counts_table)):
                           match(end.names[1],colnames(norm.counts_table)),
                         match(start.names[2],colnames(norm.counts_table)):
                           match(end.names[2],colnames(norm.counts_table)))
  norm.counts_table_subset = norm.counts_table[desired_col_ranges]
  
  desired_row_ranges = c(match(start.names[1],norm.counts_sample.table$sample_ID):
                           match(end.names[1],norm.counts_sample.table$sample_ID),
                         match(start.names[2],norm.counts_sample.table$sample_ID):
                           match(end.names[2],norm.counts_sample.table$sample_ID))
  norm.counts_sample.table_subset = norm.counts_sample.table[desired_row_ranges,]
  
  norm.counts_start.table <- norm.counts_sample.table_subset
  norm.counts_datalist = list()
  
  for(word in list_of_interest){
    if(gene.type == 'ID'){
      gene_ID = word
      gene_name = as.character(translation_table[translation_table$'submitted_id' == word, ][[4]])
    }
    if(gene.type == 'name'){
      gene_ID = as.character(translation_table[translation_table$'current_symbol' == word, ][[1]])
      gene_name = word
    }
    if(gene_ID %in% rownames(norm.counts_table_subset)){
      norm.counts <- melt(norm.counts_table_subset[gene_ID,])$"value"
      norm.counts_start.table["norm.counts"] <- norm.counts
      norm.counts_start.table["gene"] <- c(rep(gene_name,length(norm.counts)))
      norm.counts_start.table["gene_ID"] <- c(rep(gene_ID,length(norm.counts)))
      norm.counts_datalist[[gene_ID]] <- norm.counts_start.table
    }
  }
  
  norm.counts_big.data = do.call(rbind,norm.counts_datalist)
  norm.counts_big.data['group'] <- paste(norm.counts_big.data$gene,
                                         norm.counts_big.data$replicate,sep="_")
  
  p1 <- ggplot(norm.counts_big.data, aes(x=hours, y=norm.counts, color=gene, group=group)) +
    geom_point(size=2) + geom_line() + 
    theme(axis.text=element_text(size=10),
          legend.text=element_text(size=10),
          legend.title=element_text(size=10),
          axis.title.x=element_text(size=12, margin=margin(15,0,0,0)),
          axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
    scale_x_continuous(breaks=unique(norm.counts_big.data$hours),
                       "time point number",labels=unique(norm.counts_big.data$time),
                       sec.axis = sec_axis(~.,breaks=unique(norm.counts_big.data$hours),
                                           "hours since injection")) +
    scale_y_continuous("normalized counts") +
    labs(title = paste0("norm counts in subset ",start,"to",end," for both replicates"))
  
  
  ### PLOT 2: logFC
  logFC_table = read.table('../Results/log_fold_change_short_ALL-DE.csv',
                           header=TRUE, row.names=1, 
                           as.is=TRUE, check.names=FALSE, sep=',')
  colnames(logFC_table) <-  c("2","3","5","6","7","8","9","10",
                              "11","12","13","14","15","16","17","18")
  logFC_table$"1" <- c(rep(0,length(rownames(logFC_table))))
  logFC_table <- logFC_table[c("1","2","3","5","6","7","8","9","10",
                               "11","12","13","14","15","16","17","18")]
  logFC_sample.table <- read.table("../Data/sample_table_logFC.txt",header=TRUE)
  logFC_sample.table <- logFC_sample.table[-c(18,19,20),]
  
  start.names = start
  end.names = end
  if(start == 4){start.names = '5'}
  if(end == 4){end.names = '3'}
  desired_col_ranges = c(match(start.names,colnames(logFC_table)):
                           match(end.names,colnames(logFC_table)))
  logFC_table_subset = logFC_table[desired_col_ranges]
  
  desired_row_ranges = c(match(start.names,logFC_sample.table$sample_name):
                           match(end.names,logFC_sample.table$sample_name))
  logFC_sample.table_subset = logFC_sample.table[desired_row_ranges,]
  
  logFC_start.table <- logFC_sample.table_subset 
  logFC_datalist = list()
  
  for(word in list_of_interest){
    if(gene.type == 'ID'){
      gene_ID = word
      gene_name = as.character(translation_table[translation_table$'submitted_id' == word, ][[4]])
    }
    if(gene.type == 'name'){
      gene_ID = as.character(translation_table[translation_table$'current_symbol' == word, ][[1]])
      gene_name = word
    }
    if(gene_ID %in% rownames(logFC_table_subset)){
      gene_logFC <- melt(logFC_table_subset[gene_ID,])$"value"
      logFC_start.table["logFC"] <- gene_logFC
      logFC_start.table["gene"] <- c(rep(gene_name,length(gene_logFC)))
      logFC_start.table["gene_ID"] <- c(rep(gene_ID,length(gene_logFC)))
      logFC_datalist[[gene_ID]] <- logFC_start.table
    }
  }
  
  logFC_big.data = do.call(rbind,logFC_datalist)
  logFC_big.data['group'] <- paste(logFC_big.data$gene,
                                   logFC_big.data$replicate,sep="_")
  
  p2 <- ggplot(logFC_big.data, aes(x=hours, y=logFC, color=gene)) +
    geom_point(size=2) + geom_line() + 
    theme(axis.text=element_text(size=10),
          legend.text=element_text(size=10),
          legend.title=element_text(size=12),
          axis.title.x=element_text(size=12, margin=margin(15,0,0,0)),
          axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
    scale_x_continuous(breaks=unique(logFC_big.data$hours),
                       "time point number",labels=unique(logFC_big.data$sample_name),
                       sec.axis = sec_axis(~.,breaks=unique(logFC_big.data$hours),
                                           "hours since injection")) +
    ylab("log fold change") +
    labs(title = "logFC of each tp compared to 0")
  
  # ### PLOT 3: normalized counts WITH SUBSET
  # if(secondgene == +1){
  #   start2 = start+1
  #   end2 = end+1
  # }
  # if(secondgene == -1){
  #   start2 = start-1
  #   end2 = end-1
  # }
  # 
  # start_to_use = min(start,start2)
  # end_to_use = max(end,end2)
  # 
  # #start.names = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == start,]$sample_ID)
  # #end.names = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == end,]$sample_ID)
  # 
  # start.names = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == start_to_use,]$sample_ID)
  # end.names = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == end_to_use,]$sample_ID)
  # 
  # if(start_to_use == 4){start.names[2] = '5B'}
  # if(end_to_use == 4){end.names[2] = '3B'}
  # 
  # desired_col_ranges = c(match(start.names[1],colnames(norm.counts_table)):
  #                          match(end.names[1],colnames(norm.counts_table)),
  #                        match(start.names[2],colnames(norm.counts_table)):
  #                          match(end.names[2],colnames(norm.counts_table)))
  # norm.counts_table_subset = norm.counts_table[desired_col_ranges]
  # 
  # desired_row_ranges = c(match(start.names[1],norm.counts_sample.table$sample_ID):
  #                          match(end.names[1],norm.counts_sample.table$sample_ID),
  #                        match(start.names[2],norm.counts_sample.table$sample_ID):
  #                          match(end.names[2],norm.counts_sample.table$sample_ID))
  # norm.counts_sample.table_subset = norm.counts_sample.table[desired_row_ranges,]
  # 
  # norm.counts_start.table <- norm.counts_sample.table_subset
  # norm.counts_datalist = list()
  # 
  # for(word in list_of_interest){
  #   if(gene.type == 'ID'){
  #     gene_ID = word
  #     gene_name = as.character(translation_table[translation_table$'submitted_id' == word, ][[4]])
  #   }
  #   if(gene.type == 'name'){
  #     gene_ID = as.character(translation_table[translation_table$'current_symbol' == word, ][[1]])
  #     gene_name = word
  #   }
  #   if(gene_ID %in% rownames(norm.counts_table_subset)){
  #     norm.counts <- melt(norm.counts_table_subset[gene_ID,])$"value"
  #     norm.counts_start.table["norm.counts"] <- norm.counts
  #     norm.counts_start.table["gene"] <- c(rep(gene_name,length(norm.counts)))
  #     norm.counts_start.table["gene_ID"] <- c(rep(gene_ID,length(norm.counts)))
  #     norm.counts_datalist[[gene_ID]] <- norm.counts_start.table
  #   }
  # }
  # 
  # norm.counts_big.data = do.call(rbind,norm.counts_datalist)
  # norm.counts_big.data['group'] <- paste(norm.counts_big.data$gene,
  #                                        norm.counts_big.data$replicate,sep="_")
  # 
  # if(secondgene == +1){
  #   start_to_remove = min(start,start2)
  #   end_to_remove = max(end,end2)
  #   start.names.remove = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == start_to_remove,]$sample_ID)
  #   end.names.remove = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == end_to_remove,]$sample_ID)
  #   if(start_to_remove == 4){start.names.remove[2] = '5B'}
  #   if(end_to_remove == 4){end.names.remove[2] = '3B'}
  #   
  #   tmp1 = norm.counts_big.data[!(as.character(norm.counts_big.data$sample_ID) %in% start.names.remove
  #                                 & norm.counts_big.data$gene == list_of_interest[2]),]
  #   tmp2 = tmp1[!(as.character(tmp1$sample_ID) %in% end.names.remove
  #                 & tmp1$gene == list_of_interest[1]),]
  #   norm.counts_big.data.filtered = tmp2
  #   norm.counts_big.data.filtered[norm.counts_big.data.filtered$gene == list_of_interest[2],]$time =
  #     norm.counts_big.data.filtered[norm.counts_big.data.filtered$gene == list_of_interest[2],]$time -1
  # }
  # if(secondgene == -1){
  #   start_to_remove = min(start,start2)
  #   end_to_remove = max(end,end2)
  #   start.names.remove = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == start_to_remove,]$sample_ID)
  #   end.names.remove = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == end_to_remove,]$sample_ID)
  #   if(start_to_remove == 4){start.names.remove[2] = '5B'}
  #   if(end_to_remove == 4){end.names.remove[2] = '3B'}
  #   
  #   tmp1 = norm.counts_big.data[!(as.character(norm.counts_big.data$sample_ID) %in% start.names.remove
  #                                 & norm.counts_big.data$gene == list_of_interest[1]),]
  #   tmp2 = tmp1[!(as.character(tmp1$sample_ID) %in% end.names.remove
  #                 & tmp1$gene == list_of_interest[2]),]
  #   norm.counts_big.data.filtered = tmp2
  #   norm.counts_big.data.filtered[norm.counts_big.data.filtered$gene == list_of_interest[2],]$time =
  #     norm.counts_big.data.filtered[norm.counts_big.data.filtered$gene == list_of_interest[2],]$time +1
  # }
  # 
  # norm.counts_big.data.filtered[norm.counts_big.data.filtered$gene == list_of_interest[2],]$hours =
  #   norm.counts_big.data.filtered[norm.counts_big.data.filtered$gene == list_of_interest[1],]$hours
  # 
  # p3 <- ggplot(norm.counts_big.data.filtered, aes(x=time, y=norm.counts, color=gene, group=group)) +
  #   geom_point(size=2) + geom_line() + 
  #   theme(axis.text=element_text(size=10),
  #         legend.text=element_text(size=10),
  #         legend.title=element_text(size=10),
  #         axis.title.x=element_text(size=12, margin=margin(15,0,0,0)),
  #         axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
  #   scale_x_continuous(paste0("time point number ",list_of_interest[1]),
  #                      sec.axis=sec_axis(~.+secondgene,
  #                                        paste0("time point number ",list_of_interest[2]))) +
  #   scale_y_continuous("norm counts") +
  #   labs(title = paste0("norm counts in ",start,"to",end,", both replicates, gene2 shifted"))
  # 
  # 
  # multiplot(p1,p2,p3, cols=2)
  multiplot(p1,p2, cols=1)
}



plot_complete <- function(list_of_interest){
  translation_table <- as.data.frame(read.table("../Data/FlyBase_IDs_conversion-table.txt",
                                                header=TRUE))
  
  ### PLOT 1: normalized counts WITH SUBSET
  norm.counts_table = read.table('../Data/normalized_counts.csv',
                                 header=TRUE, row.names=1, 
                                 as.is=TRUE, check.names=FALSE, sep=',')
  norm.counts_table = subset(norm.counts_table, select = -c(4))
  norm.counts_sample.table <- read.csv("../Data/samples_table_no_4B.csv",header=TRUE)
  norm.counts_sample.table <- norm.counts_sample.table[-c(4),]
  
  start=1
  end=21
  start.names = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == start,]$sample_ID)
  end.names = as.vector(norm.counts_sample.table[norm.counts_sample.table$time == end,]$sample_ID)
  desired_col_ranges = c(match(start.names[1],colnames(norm.counts_table)):
                           match(end.names[1],colnames(norm.counts_table)),
                         match(start.names[2],colnames(norm.counts_table)):
                           match(end.names[2],colnames(norm.counts_table)))
  norm.counts_table_subset = norm.counts_table[desired_col_ranges]
  
  desired_row_ranges = c(match(start.names[1],norm.counts_sample.table$sample_ID):
                           match(end.names[1],norm.counts_sample.table$sample_ID),
                         match(start.names[2],norm.counts_sample.table$sample_ID):
                           match(end.names[2],norm.counts_sample.table$sample_ID))
  norm.counts_sample.table_subset = norm.counts_sample.table[desired_row_ranges,]
  
  norm.counts_start.table <- norm.counts_sample.table_subset
  norm.counts_datalist = list()
  
  for(word in list_of_interest){
    gene_ID = as.character(translation_table[translation_table$'current_symbol' == word, ][[1]])
    gene_name = word
    if(gene_ID %in% rownames(norm.counts_table_subset)){
      norm.counts <- melt(norm.counts_table_subset[gene_ID,])$"value"
      norm.counts_start.table["norm.counts"] <- norm.counts
      norm.counts_start.table["gene"] <- c(rep(gene_name,length(norm.counts)))
      norm.counts_start.table["gene_ID"] <- c(rep(gene_ID,length(norm.counts)))
      norm.counts_datalist[[gene_ID]] <- norm.counts_start.table
    }
  }
  
  norm.counts_big.data = do.call(rbind,norm.counts_datalist)
  norm.counts_big.data['group'] <- paste(norm.counts_big.data$gene,
                                         norm.counts_big.data$replicate,sep="_")
  
  p1 <- ggplot(norm.counts_big.data, aes(x=hours, y=norm.counts, color=gene, group=group)) +
    geom_point(size=2) + geom_line() + 
    theme(axis.text=element_text(size=10),
          legend.text=element_text(size=10),
          legend.title=element_text(size=10),
          axis.title.x=element_text(size=12, margin=margin(15,0,0,0)),
          axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
    scale_x_continuous(breaks=unique(norm.counts_big.data$hours),
                       "time point number",labels=unique(norm.counts_big.data$time),
                       sec.axis = sec_axis(~.,breaks=unique(norm.counts_big.data$hours),
                                           "hours since injection")) +
    scale_y_continuous("normalized counts") +
    labs(title = paste0("norm counts in subset ",start,"to",end," for both replicates"))
  
  
  ### PLOT 2: logFC
  logFC_table = read.table('../Results/log_fold_change_full_ALL-DE.csv',
                           header=TRUE, row.names=1, 
                           as.is=TRUE, check.names=FALSE, sep=',')
  colnames(logFC_table) <-  c("2","3","5","6","7","8","9","10",
                              "11","12","13","14","15","16","17","18","19","20","21")
  logFC_table$"1" <- c(rep(0,length(rownames(logFC_table))))
  logFC_table <- logFC_table[c("1","2","3","5","6","7","8","9","10",
                               "11","12","13","14","15","16","17","18","19","20","21")]
  logFC_sample.table <- read.table("../Data/sample_table_logFC.txt",header=TRUE)

  start.names = start
  end.names = end
  desired_col_ranges = c(match(start.names,colnames(logFC_table)):
                           match(end.names,colnames(logFC_table)))
  logFC_table_subset = logFC_table[desired_col_ranges]
  
  desired_row_ranges = c(match(start.names,logFC_sample.table$sample_name):
                           match(end.names,logFC_sample.table$sample_name))
  logFC_sample.table_subset = logFC_sample.table[desired_row_ranges,]
  
  logFC_start.table <- logFC_sample.table_subset 
  logFC_datalist = list()
  
  for(word in list_of_interest){
    if(word %in% rownames(logFC_table_subset)){
      gene_logFC <- melt(logFC_table_subset[word,])$"value"
      logFC_start.table["logFC"] <- gene_logFC
      logFC_start.table["gene"] <- c(rep(word,length(gene_logFC)))
      logFC_start.table["gene_ID"] <- c(rep(word,length(gene_logFC)))
      logFC_datalist[[word]] <- logFC_start.table
    }
  }
  
  logFC_big.data = do.call(rbind,logFC_datalist)
  
  p2 <- ggplot(logFC_big.data, aes(x=hours, y=logFC, color=gene)) +
    geom_point(size=2) + geom_line() + 
    theme(axis.text=element_text(size=10),
          legend.text=element_text(size=10),
          legend.title=element_text(size=12),
          axis.title.x=element_text(size=12, margin=margin(15,0,0,0)),
          axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
    scale_x_continuous(breaks=unique(logFC_big.data$hours),
                       "time point number",labels=unique(logFC_big.data$sample_name),
                       sec.axis = sec_axis(~.,breaks=unique(logFC_big.data$hours),
                                           "hours since injection")) +
    ylab("log fold change") +
    labs(title = "logFC of each tp compared to 0")
  

  multiplot(p1,p2, cols=1)
}

#list_of_interest <- c("PGRP-LA","PGRP-LC")
#gene.type='name'
#start = 8
#end = 13

# to use
#plot_subset('name',c("PGRP-LA","PGRP-LC"),8,13)

#############################################################
#	DRAW HEATMAPS:
#############################################################
draw.heatmap = function(toplot     # a matrix of size #genes x (#timepts), gene names on rownames, and time_ID on colnames
, pdfname = NULL
, block.height = 0.35
, cexCol = 0.8
, row.permute=TRUE
, col.permute=FALSE
, draw.dendrogram = 'row'  # options: 'both', 'row', 'column', 'none'
#, save.sample.order = FALSE
#, pdf.width = 7
					){
colLength = 150
HMcol = colorpanel(colLength, low='red', mid='white', high='green')
myBreaks = c(-7:-3, seq(from=-2, to=2, length.out=colLength-9), 3:7)


# scale the rows and do not use scaling from heatmap.2
# toplot=t(scale(t(toplot), center=TRUE, scale=TRUE))


# pdf(file=pdfname, height = 2.5+ifelse(no.name == FALSE, block.height, 0.1)*dim(dat)[1]*ifelse(split.in.half==TRUE, 0.75,1), width = pdf.width)

heatmap.2(toplot, col=HMcol, scale="none", Rowv=row.permute, Colv=col.permute,
	key=TRUE, keysize=0.35, symkey=FALSE,  # ColSideColors=mycol, 
	density.info="none", trace="none", cexRow=0.85, labCol=rownames(toplot), labRow = rownames(toplot), cexCol=cexCol,
	breaks=myBreaks, lwid=c(2,7), lhei=c(1.5, ifelse(no.name == FALSE, block.height, 0.1)*dim(dat)[1]), margins=c(5, 13),
	dendrogram = draw.dendrogram
	)

	  # dev.off()


}




# de <- DESeqDataSetFromMatrix(
#   countData = dd
# , colData = data.frame(row.names=time_ID_A
#                     , condition = rep("wt", 21)
#                     , time = (time_ID_A))
# , design = ~ time + time:time
#   )

# Documentation of input variables
# all_genes:
# no_genes: 
# gene_from, gene_to: 
compare_edge_random_geneset <- function(all_genes, no_genes = 200-2, gene_from, gene_to, no_rep = 10
                                      , dat.A, dat.B, ... ){

rk_table = array(0, c(no_rep, 3))
colnames(rk_table) = c('pwvar', 'l1var_hdi', 'l1var_JM')

store_genes = array("", c(no_rep, no_genes+2))

all_genes_except_from_to = setdiff(all_genes, c(gene_from, gene_to))
									  
for (rr in 1:no_rep){	
print(paste0('rep = ', rr))								  
genelist.random<-c(sample(all_genes_except_from_to,no_genes),gene_from, gene_to)

store_genes[rr,] = genelist.random
save(store_genes, file='random_genesets.RData')

dat.A.sub <- dat.A[rownames(dat.A) %in% genelist.random,]
dat.B.sub <- dat.B[rownames(dat.B) %in% genelist.random,]

if (any(rownames(dat.A.sub) !=rownames(dat.B.sub))){print('error: gene names in two replicates not matching !!')}

out <- GCnet_pwvar(dat.A = dat.A.sub, dat.B = dat.B.sub,
                   genesets = genelist.random, ... 
                   )
out$test_statistic <- array(0, c(no_genes+2, no_genes+2))				   
out_table <- network2table(out)
rk_table[rr, 1] <- which(out_table$Gene1 == gene_to & out_table$Gene2 == gene_from)

out <- GCnet_l1var(dat.A = dat.A.sub, dat.B = dat.B.sub,
                   genesets = genelist.random, use.package.hdi = TRUE
				   , ...)
out_table <- network2table(out)
rk_table[rr, 2] <- which(out_table$Gene1 == gene_to & out_table$Gene2 == gene_from)


out <- GCnet_l1var(dat.A = dat.A.sub, dat.B = dat.B.sub,
                   genesets = genelist.random, use.package.hdi = FALSE
				   , ...)
out_table <- network2table(out)
rk_table[rr, 3] <- which(out_table$Gene1 == gene_to & out_table$Gene2 == gene_from)


}

return(rk_table)
}



