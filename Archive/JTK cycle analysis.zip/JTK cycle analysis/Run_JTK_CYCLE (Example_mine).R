test<- read.csv("normalized_counts_gene-names.csv",
                header=TRUE, as.is=TRUE, 
                check.names=FALSE, sep=',')
colnames(test) 
order <- c("Probe","1A","1B","7A","7B","10A","10B","12.5A","12.5B","14A","14B",
           "15A","15B","16A","16B","17A","17B","18A","18B")
test2 <- test[,order]

source("JTK_CYCLEv3.1.R")

project <- "example_mine"

options(stringsAsFactors=FALSE)
annot <- as.data.frame(test[,1])
data <- test2[,order]

rownames(data) <- data[,1]
data <- data[,-1]
jtkdist(9, 2)       # 9 total time points, 2 replicates per time point

periods <- 4:6     # looking for rhythms between 20-28 hours (i.e. between 5 and 7 time points per cycle).
jtk.init(periods,6)  # 4 is the number of hours between time points

cat("JTK analysis started on",date(),"\n")
flush.console()

st <- system.time({
  res <- apply(data,1,function(z) {
    jtkx(z)
    c(JTK.ADJP,JTK.PERIOD,JTK.LAG,JTK.AMP)
  })
  res <- as.data.frame(t(res))
  bhq <- p.adjust(unlist(res[,1]),"BH")
  res <- cbind(bhq,res)
  colnames(res) <- c("BH.Q","ADJ.P","PER","LAG","AMP")
  results <- cbind(annot,res,data)
  results <- results[order(res$ADJ.P,-res$AMP),]
})
print(st)

save(results,file=paste("JTK",project,"rda",sep="."))
write.table(results,file=paste("JTK",project,"txt",sep="."),row.names=F,col.names=T,quote=F,sep="\t")

filtered_results <- results[results$ADJ.P < 0.01,]
write.table(filtered_results,file=paste("filtered_JTK",project,"txt",sep="."),row.names=F,col.names=T,quote=F,sep="\t")

load("JTK.example_mine.rda")
load("Gene_Master_Summary_new.RData")

filtered_results <- results[results$ADJ.P < 0.01,]
filtered_results_2 <- filtered_results[filtered_results$AMP > 0.5,]
filtered_results_3 <- filtered_results_2[filtered_results_2$BH.Q < 0.05,]
nrow(filtered_results_3)
top_cyclic <- filtered_results_3$`test[, 1]`

save(top_cyclic,file="top_cyclic.Rdata")

summary <- my_data_final[my_data_final$GeneSymbol %in% top_cyclic,]

