## filter pathways based on TENTATIVE SUBSET after the GSA run

load("tentative_subset.RData")
load("new_GO_terms.RData")

input_file <- read.csv("all_scores_filtered_p.value_0.05_score_2.5_1tp_gene-numbers_gene-list_filtered_FIXED.csv",
                       row.names = 1)[,-c(1,18)]

list_of_pathways <- rownames(input_file)

geneset.obj   <- m_list
geneset.names <- unique(names(m_list))
genes_from_time_course <- TENTATIVE_SUBSET
indexing_file <- read.csv("control_vs_1hour.csv")

gene_num_pathway_from_my_data <- list()
list_of_genes_in_pathway <- list()
all_genes <- c()

for(pathway in list_of_pathways){
  pathway_number <- as.numeric(indexing_file[indexing_file$Gene_set_name == as.character(pathway),]["Gene_set"])
  pathway_number
  
  geneset.names[pathway_number]
  genes_of_interest <- geneset.obj[pathway_number][[1]]
  genes_of_interest
  
  list_of_interest <- genes_of_interest
  genes_in_pathway = c()
  
  for(gene in list_of_interest){
    if(gene %in% genes_from_time_course){
      genes_in_pathway = c(genes_in_pathway,gene)
      if(!gene %in% all_genes){
        all_genes <- c(all_genes,gene)
      }
    }
  }
  if(length(genes_in_pathway) > 0){
    gene_num_pathway_from_my_data[[pathway]] <- length(genes_in_pathway)
  }
  list_of_genes_in_pathway[[pathway]] <- genes_in_pathway
}

num_genes <- as.character(gene_num_pathway_from_my_data)

subset_genes <- list_of_genes_in_pathway

input_file_subset <- input_file[names(list_of_genes_in_pathway),]
  
input_file_subset$genes_subset <- as.character(list_of_genes_in_pathway)
input_file_subset$num_genes <- as.character(gene_num_pathway_from_my_data)

nrow(input_file_subset)

hist(as.numeric(input_file_subset$num_genes),breaks = 20)
keep <- as.numeric(input_file_subset$num_genes) > 1
all_pathways_filtered <- input_file_subset[keep,]
nrow(all_pathways_filtered)
# we end up with 44

duplicated(all_pathways_filtered$genes)
# three pathways should be removed

all_pathways_filtered <- all_pathways_filtered[!rownames(all_pathways_filtered) == "exopeptidase activity",]
all_pathways_filtered <- all_pathways_filtered[!rownames(all_pathways_filtered) == "N-acetylmuramoyl-L-alanine amidase activity",]
all_pathways_filtered <- all_pathways_filtered[!rownames(all_pathways_filtered) == "negative regulation of natural killer cell differentiation involved in immune response",]

faux_logFC <- as.matrix(read.csv("all_scores_100000perm.csv",row.names=2)[,-1])
faux_logFC <- faux_logFC[,1:17]

all_scores_subset_pathways <- as.data.frame(faux_logFC[rownames(faux_logFC) %in% row.names(all_pathways_filtered),])
nrow(all_scores_subset_pathways)


#### 3 pathways removed due to repetition of gene sets, going from 44 to 41
# exopeptidase activity
# N-acetylmuramoyl-L-alanine amidase activity
# negative regulation of natural killer cell differentiation involved in immune response
### cutoffs chosen:
# pvalue 0.05
# score 2.5
# in at least one time point
# reduced 551 subset


library(pheatmap)
library(RColorBrewer)
library(dendsort)

all_scores_subset_pathways$pathway_size <- NULL
mat <- as.matrix(all_scores_subset_pathways)

pheatmap(mat,cluster_cols = FALSE,show_rownames=T) # simple heatmap

colnames(mat) <- c(1,2,4,5,6,8,10,12,14,16,20,24,30,36,42,48)

mat_breaks <- seq(-max(mat), max(mat), length.out = 12)

# FINAL PLOT
name = "GSA_heatmap_41pathways.pdf"
pdf(name,width=10,height=8.5,paper="special")

pheatmap(mat, 
         cluster_col  = FALSE, 
         color        = rev(brewer.pal(11, "PuOr")),
         angle_col    = 0,
         breaks = mat_breaks,
         show_rownames= T,
         fontsize          = 12,
         fontsize_row      = 8,
         fontsize_col      = 12,
         cluster_rows = T
      #   clustering_distance_rows = "canberra"
         )

dev.off()



### plot genes in each pathway

# 
# library(reshape2)
# library(ggplot2)
# input_counts <- read.table('normalized_counts_gene-names.csv',
#                            header=TRUE, row.names=1, as.is=TRUE, 
#                            check.names=FALSE, sep=',')
# samples_table <- read.csv("samples_table_no_4B.csv")
# start_table$hours <- as.factor(start_table$hours)
# 
# pathways <- rownames(mat)
# #pathways[17] <- "cyclin-dependent protein serine threonine kinase regulator activity"
# #i=1
# for(i in 1:length(pathways)){
#   list_of_interest <- list_of_genes_in_pathway[[rownames(mat)[i]]]
#   pathway <- pathways[i]
#   genes_from_time_course <- input_counts 
#   start_table <- samples_table
#   
#   print(pathway)
#   print(rownames(mat)[i])
#   
#   datalist = list()
#   
#   for(word in list_of_interest){
#     if(word %in% rownames(genes_from_time_course)){
#       gene_counts <- melt(genes_from_time_course[word,])$"value"
#       start_table["counts"] <- gene_counts
#       start_table["Gene"] <- c(rep(word,length(gene_counts)))
#       start_table["gene_ID"] <- c(rep(word,length(gene_counts)))
#       start_table["type"] <- c(rep("norm_counts",length(gene_counts)))
#       datalist[[word]] <- start_table
#     }
#   }
#   
#   big_data = do.call(rbind,datalist)
#   
#   big_data['group'] <- paste(big_data$gene,big_data$replicate,sep="_")
#   
#   name = paste0("GSA top pathway plots/Figure_",pathway,"_norm-counts.pdf")
#   pdf(name,width=7,height=3.5,paper="special")
#   
#   print(ggplot(big_data, aes(x=hours, y=counts, color=Gene, group=group)) +
#           geom_point(size=2) + 
#           geom_line() +
#           #stat_summary(fun.y = mean, geom="line", mapping = aes(group=Gene), size=1) +
#           theme(axis.text=element_text(size=12),
#                 legend.text=element_text(size=12),
#                 legend.title=element_text(size=12),
#                 axis.title.x=element_text(size=12, margin=margin(5,0,0,0)),
#                 axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
#           scale_y_log10() +
#           ylab("Normalized counts") +
#           xlab("hours since injection") +
#           labs(title = paste(strwrap(pathway,width=70), collapse="\n")))
#   
#   dev.off()
# }
# 
# 
# ## logFC
# logFC_table = read.table('log_fold_change_full_ALL-DE.csv',
#                          header=TRUE, row.names=1, 
#                          as.is=TRUE, check.names=FALSE, sep=',')
# colnames(logFC_table) <-  c("2","3","5","6","7","8","9","10",
#                             "11","12","13","14","15","16","17","18","19","20","21")
# logFC_table$"1" <- c(rep(0,length(rownames(logFC_table))))
# logFC_table <- logFC_table[c("1","2","3","5","6","7","8","9","10",
#                              "11","12","13","14","15","16","17","18","19","20","21")]
# logFC_sample.table <- read.table("sample_table_logFC.txt",header=TRUE)
# 
# genes_from_time_course <- logFC_table 
# 
# for(i in 1:length(pathways)){
#   list_of_interest <- list_of_genes_in_pathway[[rownames(mat)[i]]]
#   pathway <- pathways[i]
# 
#   print(pathway)
#   print(rownames(mat)[i])
#   
#   logFC_start.table <- logFC_sample.table
#   
#   logFC_datalist = list()
#   
#   for(word in list_of_interest){
#     if(word %in% rownames(logFC_table)){
#       gene_logFC <- melt(logFC_table[word,])$"value"
#       logFC_start.table["logFC"] <- gene_logFC
#       logFC_start.table["gene"] <- c(rep(word,length(gene_logFC)))
#       logFC_start.table["gene_ID"] <- c(rep(word,length(gene_logFC)))
#       logFC_datalist[[word]] <- logFC_start.table
#     }
#   }
#   
#   logFC_big.data = do.call(rbind,logFC_datalist)
#   
#   name = paste0("GSA top pathway plots/Figure_",pathway,"_logFC.pdf")
#   pdf(name,width=7,height=3.5,paper="special")
#   
#   print( ggplot(logFC_big.data, aes(x=hours, y=logFC, color=gene)) +
#            geom_point(size=2) + 
#            geom_line() + 
#            theme(axis.text=element_text(size=10),
#                  legend.text=element_text(size=10),
#                  legend.title=element_text(size=12),
#                  axis.title.x=element_text(size=12, margin=margin(15,0,0,0)),
#                  axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
#            xlab("hours since injection") +
#            ylab("log fold change") +
#            labs(title = paste(strwrap(pathway,width=70), collapse="\n")))
#   
#   dev.off()
# }
# 
