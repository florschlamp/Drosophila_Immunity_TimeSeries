# new plots, revisions June 2020

dat_logFC_short <- read.table('log_fold_change_short.filtered_ALL_spline_3.csv',
                              header=TRUE, row.names=1, as.is=TRUE, 
                              check.names=FALSE, sep=',')
colnames(dat_logFC_short) <-  c("2","3","5","6","7","8","9","10",
                                "11","12","13","14","15","16","17","18")
dat_logFC_short$"1" <- c(rep(0,length(rownames(dat_logFC_short))))
dat_logFC_short <- dat_logFC_short[c("1","2","3","5","6","7","8","9","10",
                                     "11","12","13","14","15","16","17","18")]
sample_table_logFC <- read.table("sample_table_logFC.txt",header=TRUE)
sample_table_short_logFC <- sample_table_logFC[-c(18,19,20),]


list_of_interest <- c("ACC", "CG33120", "FASN1", "Lpin", "mdy", "mino")

dat_logFC <- dat_logFC_short
logFC_start.table <- sample_table_short_logFC
logFC_datalist = list()

for(word in list_of_interest){
  if(word %in% rownames(dat_logFC)){
    gene_logFC <- melt(dat_logFC[word,])$"value"
    logFC_start.table["logFC"] <- gene_logFC
    logFC_start.table["gene"] <- c(rep(word,length(gene_logFC)))
    logFC_start.table["gene_ID"] <- c(rep(word,length(gene_logFC)))
    logFC_datalist[[word]] <- logFC_start.table
  }
}

logFC_big.data = do.call(rbind,logFC_datalist)

#name = paste0("triglyceride_biosynthetic_process(new).pdf")
#pdf(name,width=6.6,height=3,paper="special")

print( ggplot(logFC_big.data, aes(x=hours, y=logFC, group=gene)) +
         geom_point(aes(x=hours, y=logFC, color=gene), size=2) +
         geom_line(aes(x=hours, y=logFC, color=gene), size=1) +
         theme(axis.text=element_text(size=12),
               legend.text=element_text(size=12),
               legend.title=element_text(size=12),
               axis.title.x=element_text(size=12, margin=margin(5,0,0,0)),
               axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
         ylab("Log Fold Change") +
         scale_x_continuous(breaks=c(0,6,12,24,36,48)) +
         xlab("Hours since injection")
       #  labs(title = paste(strwrap(pathway,width=70), collapse="\n"))
       )

#dev.off() 


#####

list_of_interest <- c("ACC", "CG7766", "CG8475", "FASN1", "GlyS", "UGP", "foxo")

dat_logFC <- dat_logFC_short
logFC_start.table <- sample_table_short_logFC
logFC_datalist = list()

for(word in list_of_interest){
  if(word %in% rownames(dat_logFC)){
    gene_logFC <- melt(dat_logFC[word,])$"value"
    logFC_start.table["logFC"] <- gene_logFC
    logFC_start.table["gene"] <- c(rep(word,length(gene_logFC)))
    logFC_start.table["gene_ID"] <- c(rep(word,length(gene_logFC)))
    logFC_datalist[[word]] <- logFC_start.table
  }
}

logFC_big.data = do.call(rbind,logFC_datalist)

#name = paste0("glycogen_metabolic_process(new).pdf")
#pdf(name,width=6.6,height=3,paper="special")

print( ggplot(logFC_big.data, aes(x=hours, y=logFC, group=gene)) +
         geom_point(aes(x=hours, y=logFC, color=gene), size=2) +
         geom_line(aes(x=hours, y=logFC, color=gene), size=1) +
         theme(axis.text=element_text(size=12),
               legend.text=element_text(size=12),
               legend.title=element_text(size=12),
               axis.title.x=element_text(size=12, margin=margin(5,0,0,0)),
               axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
         ylab("Log Fold Change") +
         scale_x_continuous(breaks=c(0,6,12,24,36,48)) +
         xlab("Hours since injection")
       #  labs(title = paste(strwrap(pathway,width=70), collapse="\n"))
)

#dev.off() 


######

list_of_interest <- c("CG9961", "G6P", "PCB", "Pgi", "Pgk", "Tpi", "fbp")

dat_logFC <- dat_logFC_short
logFC_start.table <- sample_table_short_logFC
logFC_datalist = list()

for(word in list_of_interest){
  if(word %in% rownames(dat_logFC)){
    gene_logFC <- melt(dat_logFC[word,])$"value"
    logFC_start.table["logFC"] <- gene_logFC
    logFC_start.table["gene"] <- c(rep(word,length(gene_logFC)))
    logFC_start.table["gene_ID"] <- c(rep(word,length(gene_logFC)))
    logFC_datalist[[word]] <- logFC_start.table
  }
}

logFC_big.data = do.call(rbind,logFC_datalist)

#name = paste0("gluconeogenesis(new).pdf")
#pdf(name,width=6.6,height=3,paper="special")

print( ggplot(logFC_big.data, aes(x=hours, y=logFC, group=gene)) +
         geom_point(aes(x=hours, y=logFC, color=gene), size=2) +
         geom_line(aes(x=hours, y=logFC, color=gene), size=1) +
         theme(axis.text=element_text(size=12),
               legend.text=element_text(size=12),
               legend.title=element_text(size=12),
               axis.title.x=element_text(size=12, margin=margin(5,0,0,0)),
               axis.title.y=element_text(size=12, margin=margin(0,5,0,0))) +
         ylab("Log Fold Change") +
         scale_x_continuous(breaks=c(0,6,12,24,36,48)) +
         xlab("Hours since injection")
       #  labs(title = paste(strwrap(pathway,width=70), collapse="\n"))
)

#dev.off() 
 