###########################################
#	FORMAT OUTPUT FROM GSA ANALYSIS, new!! adapted April 7th 2019
###########################################
format.output = function(GSA.listsets.obj
                         , geneset.obj
){
  label.neg = 'DOWN'; label.pos = 'UP'
  
  if (GSA.listsets.obj$nsets.neg){
    t.n = GSA.listsets.obj$negative
    pathway_size = array(0, length(t.n[,2]))
    for (i in 1:length(t.n[,2])){
      pathway_size[i] = length(geneset.obj[[as.numeric(t.n[i,1])]])
    }
    direction=rep(label.neg, nrow(t.n))
    GSA.listsets.obj$negative = cbind(GSA.listsets.obj$negative, pathway_size, direction)
  }
  if (GSA.listsets.obj$nsets.pos){
    t.p = GSA.listsets.obj$positive
    pathway_size = array(0, length(t.p[,2]))
    for (i in 1:length(t.p[,2])){
      pathway_size[i] = length(geneset.obj[[as.numeric(t.p[i,1])]])
    }
    direction=rep(label.pos, nrow(t.p))
    GSA.listsets.obj$positive = cbind(GSA.listsets.obj$positive, pathway_size, direction)
  }
  if (!(GSA.listsets.obj$nsets.neg | GSA.listsets.obj$nsets.pos))
    GSA.listsets.obj$all <- NULL
  else if (!GSA.listsets.obj$nsets.neg)
    GSA.listsets.obj$all=GSA.listsets.obj$pos
  else if (!GSA.listsets.obj$nsets.pos)
    GSA.listsets.obj$all=GSA.listsets.obj$neg
  else
    GSA.listsets.obj$all=rbind(GSA.listsets.obj$neg, GSA.listsets.obj$pos)
  
  GSA.listsets.obj$all=GSA.listsets.obj$all[order(GSA.listsets.obj$all[,2]),]
  GSA.listsets.obj$all = data.frame(GSA.listsets.obj$all, stringsAsFactors=FALSE, check.names=FALSE)
  GSA.listsets.obj$all$Gene_set = as.numeric(GSA.listsets.obj$all$Gene_set)
  GSA.listsets.obj$all$Score = as.numeric(GSA.listsets.obj$all$Score)
  GSA.listsets.obj$all$pathway_size = as.numeric(GSA.listsets.obj$all$pathway_size)
  GSA.listsets.obj$all$FDR = as.numeric(GSA.listsets.obj$all$FDR)
  GSA.listsets.obj$all$"p-value" = as.numeric(GSA.listsets.obj$all$"p-value")
  GSA.listsets.obj$all$FDRBH = p.adjust(GSA.listsets.obj$all$"p-value", method="BH")
  GSA.listsets.obj$all$FDRBY = p.adjust(GSA.listsets.obj$all$"p-value", method="BY")
  
  return(GSA.listsets.obj$all)	
}
