# first step after running GSA in the server

#append all scores to new file

samples_table <- read.csv("samples_table_no_4B.csv",
                          header=TRUE, row.names=1, as.is=TRUE, 
                          check.names=FALSE, sep=',')

for(sample_number in 2:21){ ## test until 17, otherwhise use 21
  if(sample_number == 4){
    next
  }
  
  hour <- samples_table[samples_table$time==sample_number,]$hours[1]
  
  if(sample_number == 2){
    print(sample_number)
    file_name <- paste0("control_vs_",hour,"hour.csv")
    file <- read.csv(file_name)
    hour_label <- paste0(hour,"h")
    
    # for score table
    current <-matrix(0,ncol=3,nrow=nrow(file))
    current[,1]<-as.character(file$Gene_set_name)
    current[,2]<-file$pathway_size
    current[,3]<-file$Score
    colnames(current) <- c("Gene_set_names","pathway_size",hour_label)
    
    # for pval table
    current_pval <-matrix(0,ncol=3,nrow=nrow(file))
    current_pval[,1]<-as.character(file$Gene_set_name)
    current_pval[,2]<-file$pathway_size
    current_pval[,3]<-file$p.value
    colnames(current_pval) <- c("Gene_set_names","pathway_size",hour_label)
  }
  
  if(sample_number != 2){
    print(sample_number)
    file_name <- paste0("control_vs_",hour,"hour.csv")
    file <- read.csv(file_name)
    hour_label <- paste0(hour,"h")
    
    # for score table
    new<-matrix(0,ncol=2,nrow=nrow(file))
    new[,1]<-as.character(file$Gene_set_name)
    new[,2]<-file$Score
    colnames(new) <- c("Gene_set_names",hour_label)
    
    # for pval table
    new_pval<-matrix(0,ncol=2,nrow=nrow(file))
    new_pval[,1]<-as.character(file$Gene_set_name)
    new_pval[,2]<-file$p.value
    colnames(new_pval) <- c("Gene_set_names",hour_label)
    
    # APPEND ALL
    current <- Reduce(function(...) merge(...,by.x='Gene_set_names',
                                          by.y='Gene_set_names'), 
                      list(current,new))
    
    current_pval <- Reduce(function(...) merge(...,by.x='Gene_set_names',
                                          by.y='Gene_set_names'), 
                      list(current_pval,new_pval))
  }
}

file_name <- paste0("all_scores_100000perm.csv")
write.csv(current,file=file_name)

file_name <- paste0("all_p.values_100000perm.csv")
write.csv(current_pval,file=file_name)

##### DONE
