# second step after formatting GSA results into one table
# (using new_format_to_one_table.R)


# read in filtering function
filter_genes <- function(
  pvalue                   # a matrix of size #genes x (#timepts-1), as in the output of DE_timecourse
  , logFC            # a matrix of size #genes x (#timepts-1), as in the output of DE_timecourse
  , p_adjust_method = 'none' # options: 'bonferroni', 'BH', 'BY', see p.adjust() for all available options
  , p_cut
  , logFC_cut
  , rule = 'and'             # options: 'and', 'or'
  , t_cut = 1            # only keep genes which are differential in atleast t_cut timepts
){
  
  if (any(dim(pvalue)!=dim(logFC))){stop("dimensions of pval and logFC do not match!!")}
  out <- logFC
  
  # correct for multiple testing
  if (p_adjust_method!='none'){
    tmp = matrix(p.adjust(as.vector(pvalue), method=p_adjust_method)
                 , nrow(pvalue), ncol(pvalue)
    )
    rownames(tmp) = rownames(pvalue)
    colnames(tmp) = colnames(pvalue)
    pvalue <- tmp
    rm(tmp)			   
  }
  
  # set all logFC with high pval and/or low logFC to zero 
  if (rule == 'and')
    out[!((pvalue <= p_cut) & (abs(logFC) >= logFC_cut))] = 0
  else
    out[!((pvalue <= p_cut) | (abs(logFC) >= logFC_cut))] = 0
  
  # keep only genes differentially expressed in atleast t_cut  points
  keep_genes_idx = (rowSums(!!out) >= t_cut)
  
  return(list(adj.pvalue = pvalue[keep_genes_idx,], logFoldChange = out[keep_genes_idx,]))
}



# all data
faux_logFC <- as.matrix(read.csv("all_scores_100000perm.csv",row.names=2)[,-1])
faux_logFC <- faux_logFC[,1:17]

pvalues <- as.matrix(read.csv("all_p.values_100000perm.csv",row.names=2)[,-1])
pvalues <- pvalues[,1:17]

load("new_GO_terms.RData")
geneset.obj   <- m_list
geneset.names <- unique(names(m_list))
genes_from_time_course <- rownames(read.csv("normalized_counts_gene-names.csv",row.names = 1)) 
indexing_file <- read.csv("control_vs_1hour.csv")

pvalues[,"pathway_size"] <- rep(0,length(pvalues[,"pathway_size"]))

hist(as.vector(as.matrix(faux_logFC[,-c(1,2)])))
hist(as.vector(as.matrix(pvalues[,-c(1,2)])))

summary(as.vector(as.matrix(faux_logFC[,2:17])))
quantile(as.vector(as.matrix(faux_logFC[,2:17])), prob = seq(0,10)/10)

# filter
p_cutoff = 0.05
score_cutoff = 2.5
timepoints = 1

filted_data = filter_genes(pvalue = pvalues, 
                           logFC = faux_logFC, 
                           p_cut = p_cutoff, 
                           logFC_cut = score_cutoff, 
                           t_cut = timepoints+1, # +1 to compensate for extra column
                           rule = 'and',
                           p_adjust_method = 'BH')

adj.p_values_f <- as.data.frame(filted_data['adj.pvalue'])
scores_f <- as.data.frame(filted_data['logFoldChange'])
nrow(adj.p_values_f)
nrow(scores_f)

colnames(scores_f) <- c("pathway_size","1h","2h","4h",
                                "5h","6h","8h","10h","12h",
                                "14h","16h","20h","24h","30h",
                                "36h","42h","48h")

### add gene list, add gene numbers 

all_pathways <- scores_f
list_of_pathways <- rownames(all_pathways)

gene_num_pathway_from_my_data <- list()
list_of_genes_in_pathway <- list()
all_genes <- c()

for(pathway in list_of_pathways){
  pathway_number <- as.numeric(indexing_file[indexing_file$Gene_set_name == as.character(pathway),]["Gene_set"])
  pathway_number

  geneset.names[pathway_number]
  genes_of_interest <- geneset.obj[pathway_number][[1]]
  genes_of_interest
  
  list_of_interest <- genes_of_interest
  genes_in_pathway = c()
  
  for(gene in list_of_interest){
    if(gene %in% genes_from_time_course){
      genes_in_pathway = c(genes_in_pathway,gene)
      if(!gene %in% all_genes){
        all_genes <- c(all_genes,gene)
      }
    }
  }
  gene_num_pathway_from_my_data[[pathway]] <- length(genes_in_pathway)
  list_of_genes_in_pathway[[pathway]] <- genes_in_pathway
}

all_pathways$num_genes <- as.character(gene_num_pathway_from_my_data)
all_pathways$genes <- as.character(list_of_genes_in_pathway)

length(all_genes)

file_name = paste0("all_scores_filtered_p.value_",p_cutoff,
                   "_score_",score_cutoff,"_",timepoints,
                   "tp_gene-numbers_gene-list_FIXED.csv")
write.csv(all_pathways,file=file_name)

## save all scores of pathways

all_scores_subset_pathways <- as.data.frame(faux_logFC[rownames(faux_logFC) %in% row.names(all_pathways),])
all_scores_subset_pathways$num_genes <- all_pathways$num_genes
all_scores_subset_pathways$genes <- all_pathways$genes

file_name = paste0("pathway_analysis_fixed/all_scores_filtered_p.value_",p_cutoff,
                   "_score_",score_cutoff,"_",timepoints,
                   "tp_gene-numbers_gene-list_FIXED_allscores.csv")
write.csv(all_scores_subset_pathways,file=file_name)

######################## filter###############################################
nrow(all_pathways)
hist(as.numeric(all_pathways$num_genes),breaks = 20)
keep <- as.numeric(all_pathways$num_genes) > 4
all_pathways_filtered <- all_pathways[keep,]
nrow(all_pathways_filtered)

file_name = paste0("pathway_analysis_fixed/all_scores_filtered_p.value_",p_cutoff,
                   "_score_",score_cutoff,"_",timepoints,
                   "tp_gene-numbers_gene-list_filtered_FIXED.csv")
write.csv(all_pathways_filtered,file=file_name)

## save all scores of filtered pathways

all_scores_subset_pathways <- as.data.frame(faux_logFC[rownames(faux_logFC) %in% row.names(all_pathways_filtered),])
all_scores_subset_pathways$num_genes <- all_pathways_filtered$num_genes
all_scores_subset_pathways$genes <- all_pathways_filtered$genes

file_name = paste0("pathway_analysis_fixed/all_scores_filtered_p.value_",p_cutoff,
                   "_score_",score_cutoff,"_",timepoints,
                   "tp_gene-numbers_gene-list_filtered_FIXED_allscores.csv")
write.csv(all_scores_subset_pathways,file=file_name)

# #####
# all_pathways_filtered$new_column <- sapply(1:nrow(all_pathways_filtered), function(index){
#   paste(all_pathways_filtered[index,2:17], collapse=",")
# })
# 
# # TO FILTER DUPLICATES 
# duplicated <- unique(all_pathways_filtered$new_column[duplicated(all_pathways_filtered$new_column)])
# 
# 
# remove <- vector()
# 
# for(i in 1:length(duplicated)){
#   duplicates <- rownames(all_pathways_filtered[all_pathways_filtered$new_column == duplicated[i],])
#   subset <- all_pathways_filtered[all_pathways_filtered$new_column == duplicated[i],][1]
#   subset$index <- match(rownames(all_pathways_filtered[all_pathways_filtered$new_column == duplicated[i],]),
#                         rownames(all_pathways_filtered))
#   remove_local <- subset$index[subset$pathway_size != min(subset$pathway_size)]
#   remove <- c(remove,remove_local)
# #  print(remove_local)
# }
# 
# remove
# dim(all_pathways_filtered)
# all_pathways_filtered2 <- all_pathways_filtered[-remove,]
# dim(all_pathways_filtered2)
# 
# 
# file_name = paste0("pathway_analysis_fixed/all_scores_",method,
#                    "_filtered_p.value_",p_cutoff,
#                    "_score_",score_cutoff,"_",timepoints,
#                    "tp_gene-numbers_gene-list_filtered_FIXED.csv")
# write.csv(all_pathways_filtered2,file=file_name)
# 
# length(all_genes)
# 
# file_name = paste0("pathway_analysis_fixed/all_genes_",method,"_p.value_",p_cutoff,
#                    "_score_",score_cutoff,"_",timepoints,"tp_",
#                    length(all_genes),".csv")
# write.csv(all_genes,file=file_name)
# 
# significant_genes <- rownames(read.csv("../Results/all_genes_short.filtered_pvalue-cut_0.1_logFC-cut_0.5_tp-cut_1_spline_3.csv", row.names = 2))
# 
# length(all_genes[all_genes %in% significant_genes])

