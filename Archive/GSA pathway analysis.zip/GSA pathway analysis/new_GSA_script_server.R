#install.packages("GSA")
#source("http://bioconductor.org/workflows.R")
#biocLite("GSA",lib="~/Rlibs")
library(GSA,lib.loc="~/Rlibs")
library(GO.db,lib.loc="~/Rlibs")
library(dplyr)
source("format_GSA_result_new.R")
load("new_GO_terms.RData")

args <- commandArgs(trailingOnly=FALSE)
sample_number <- args[4] #2 to 21, skip 4
npermutations = 100000

print(sample_number)
print(npermutations)

input_counts  <- read.csv("normalized_counts_gene-names.csv",
                          header=TRUE, row.names=1, as.is=TRUE, 
                          check.names=FALSE, sep=',')
samples_table <- read.csv("samples_table_no_4B.csv",
                          header=TRUE, row.names=1, as.is=TRUE, 
                          check.names=FALSE, sep=',')
genenames     <- rownames(input_counts)
geneset.obj   <- m_list
geneset.names <- names(m_list)


# 1 hour vs...
x<-matrix(0,ncol=4,nrow=nrow(input_counts))
x[,1] <- input_counts[,"1A"]
x[,3] <- input_counts[,"1B"]
y<-c(-1,1,-2,2)
maxchar =  max(nchar(geneset.names)) 

# ... vs hour that corresponds to desired sample_number
replicateA <- paste0(as.character(sample_number),"A")
replicateB <- paste0(as.character(sample_number),"B")
x[,2] <- input_counts[,replicateA]
x[,4] <- input_counts[,replicateB]

GSA.obj<-GSA(x,y, genenames=genenames, genesets=geneset.obj, 
             resp.type="Two class paired", nperms=npermutations, minsize = 5)
GSA.listsets.obj = GSA.listsets(GSA.obj, geneset.names=geneset.names, FDRcut=1, maxchar = maxchar)
GSA.output.table = format.output(GSA.listsets.obj, geneset.obj)
hour <- samples_table[samples_table$time==sample_number,]$hours[1]
file_name = paste0("control_vs_",hour,"hour.csv")
write.csv(GSA.output.table,file=file_name)

rm(GSA.output.table)