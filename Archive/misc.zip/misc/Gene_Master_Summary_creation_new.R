# create database drosophila genes
my_original_data <- read.table("FlyBase_IDs_conversion-table.txt",
                               stringsAsFactors = FALSE)
colnames(my_original_data) <- my_original_data[1,]
my_original_data <- my_original_data[-1,]
my_original_data$submitted_id <- NULL
my_original_data$converted_id <- NULL
colnames(my_original_data) <- c("FBgn_ID","GeneSymbol")

snapshots <- read.table("gene_snapshots_fb_2018_06.txt",
                        sep="\t",fill=TRUE, stringsAsFactors = FALSE,
                        quote="")
colnames(snapshots) <- snapshots[1,]
snapshots <- snapshots[-1,] 
snapshots$datestamp <- NULL
colnames(snapshots)

my_data <- merge(my_original_data,snapshots,by=c("GeneSymbol"),all.x=TRUE)

# example
my_data[my_data$GeneSymbol=="Orc1",]

gtf_file <- read.table("dmel-all-r6.17.gtf",sep="\t")
gtf_file_filtered <- gtf_file[gtf_file$V3 == 'gene',]

gtf_file_filtered$V8 <- NULL
gtf_file_filtered$V6 <- NULL
gtf_file_filtered$V3 <- NULL
gtf_file_filtered$V2 <- NULL

foo <- data.frame(do.call('rbind', 
                          strsplit(as.character(gtf_file_filtered$V9),
                                   ';',fixed=TRUE)))
foo2 <- data.frame(do.call('rbind', 
                           strsplit(as.character(foo$X1),
                                    ' ',fixed=TRUE)))
foo3 <- data.frame(do.call('rbind', 
                           strsplit(as.character(foo$X2),
                                    ' ',fixed=TRUE)))
gtf_file_filtered$V9 <- NULL
colnames(gtf_file_filtered) <- c("chr","start","end","strand")
gtf_file_filtered$"GeneSymbol" <- foo3$X3
gtf_file_filtered$"FBgn_ID" <- foo2$X2

rm(foo,foo2,foo3)

my_data_2 <- merge(my_data,gtf_file_filtered,by=c("GeneSymbol"))

# example
my_data_2[my_data_2$GeneSymbol=="Orc1",]

genes_of_interest <- read.csv("normalized_counts.csv")
genes_of_interest <- genes_of_interest$X

my_data_3 <- my_data_2[my_data_2$FBgn_ID.x %in% genes_of_interest,]

# example
my_data_3[my_data_3$GeneSymbol=="Orc1",]

gene_associations <- read.table("gene_association_2019_01.txt",
                                stringsAsFactors = FALSE)
colnames(gene_associations) <- gene_associations[1,]
gene_associations <- gene_associations[-1,] 
gene_associations_filtered <- gene_associations[gene_associations$Gene_Symbol %in% my_data_3$GeneSymbol,]
colnames(gene_associations_filtered)

library(plyr)
gene_associations_filtered_summarized <- ddply(gene_associations_filtered, 
                                               .(Gene_Symbol), 
                                               summarize, GO_IDs = toString(GO_ID))

rm(gene_associations_filtered,gtf_file,gtf_file_filtered)
rm(my_original_data,snapshots)

colnames(my_data_3)
colnames(gene_associations_filtered_summarized) <- c("GeneSymbol","GO_IDs")

my_data_final <- merge(my_data_3,gene_associations_filtered_summarized,
                 by=c("GeneSymbol"),all.x=TRUE)

my_data_final[my_data_final$GeneSymbol=="Orc1",]

save(my_data_final,file="Gene_Master_Summary_new.RData")


####  create gmt file #####
gene_associations <- read.table("gene_association_2019_01.txt",
                                stringsAsFactors = FALSE)
colnames(gene_associations) <- gene_associations[1,]
gene_associations <- gene_associations[-1,] 

gene_associations$Gene_Symbol<-NULL
gene_associations_summarized <- ddply(gene_associations,
                                      .(GO_ID), 
                                      summarize, FBgn_IDs = toString(FlyBase_ID))

library(goseq)
library(GO.db)

get_GO_term_descr =  function(x) {
  d = 'none';
  go_info = GOTERM[[x]];
  if (length(go_info) >0) { d = paste(Ontology(go_info), Term(go_info), sep=' ');}
  return(d);
}

get_GO_term_descr("GO:0000003")

#or:
library(GO.db)
Term("GO:0000002")

gene_associations_summarized$description <- as.character(Term(gene_associations_summarized$GO_ID))
gene_associations_summarized <- gene_associations_summarized[,c(1,3,2)]
write.csv(gene_associations_summarized,file="GO_terms_FlyBaseID.csv")

## with symbols
gene_associations <- read.table("gene_association_2019_01.txt",
                                stringsAsFactors = FALSE)
colnames(gene_associations) <- gene_associations[1,]
gene_associations <- gene_associations[-1,] 

gene_associations$FlyBase_ID<-NULL
gene_associations_summarized <- ddply(gene_associations,
                                      .(GO_ID), 
                                      summarize, Genes = toString(Gene_Symbol))
gene_associations_summarized$description <- as.character(Term(gene_associations_summarized$GO_ID))
gene_associations_summarized <- gene_associations_summarized[,c(1,3,2)]

write.csv(gene_associations_summarized,file="GO_terms_GeneSymbol.csv")

### FINAL ####

gene_associations <- read.table("gene_association_2019_01.txt",
                                stringsAsFactors = FALSE)
colnames(gene_associations) <- gene_associations[1,]
gene_associations <- gene_associations[-1,] 

gene_associations$FlyBase_ID<-NULL

gene_associations$description <- as.character(Term(gene_associations$GO_ID))

# remove NAs
gene_associations <- gene_associations[complete.cases(gene_associations),]

m_list = gene_associations %>% split(x = .$Gene_Symbol, f = .$description)

save(m_list,file="new_GO_terms.RData")






